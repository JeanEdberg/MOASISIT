import{a as e,n as t,t as n}from"./jsx-runtime-BVQXJMCF.js";import{n as r,r as i}from"./store-CjYBk8gJ.js";var a=e(t(),1),o=n();function s(){let{employees:e,company:t,areas:n}=r(),[s,c]=(0,a.useState)(`cts-nov`),[l,u]=(0,a.useState)(``),[d,f]=(0,a.useState)(`todas`),p=t.id===`inmoa`?`interbank`:t.id===`7pollitos`?`bbva`:`bcp`,[m,h]=(0,a.useState)(p),g=new Date().getFullYear(),_=i(e,t,s,g).filter(t=>{let n=e.find(e=>e.dni===t.dni),r=t.dni.toLowerCase().includes(l.toLowerCase())||(t.name||t.nombre||``).toLowerCase().includes(l.toLowerCase()),i=d===`todas`||n&&n.areaId===d;return r&&i}),v=_.reduce((e,t)=>e+t.totalPagar,0),y=s.includes(`cts`),b=y?`Banco CTS`:`Banco Sueldo`,x=y?`N° Cuenta CTS`:`N° Cuenta Sueldo`,S=(e,t)=>{let n=new Blob([e],{type:`text/plain;charset=utf-8;`}),r=URL.createObjectURL(n),i=document.createElement(`a`);i.href=r,i.setAttribute(`download`,t),document.body.appendChild(i),i.click(),document.body.removeChild(i)};return(0,o.jsxs)(`div`,{className:`p-6 bg-white rounded-xl shadow-sm border border-slate-200 space-y-6`,children:[(0,o.jsxs)(`div`,{className:`flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b pb-4`,children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`h2`,{className:`text-xl font-bold text-slate-900`,children:`Consolidado Masivo de Beneficios Sociales`}),(0,o.jsxs)(`p`,{className:`text-sm text-slate-500`,children:[t.name,` — RUC: `,t.ruc]})]}),(0,o.jsxs)(`div`,{className:`flex flex-wrap items-center gap-2`,children:[(0,o.jsxs)(`select`,{value:s,onChange:e=>c(e.target.value),className:`px-3 py-2 border rounded-lg text-sm bg-slate-50 font-medium text-slate-700`,children:[(0,o.jsx)(`option`,{value:`cts-nov`,children:`CTS Semestre Noviembre`}),(0,o.jsx)(`option`,{value:`cts-may`,children:`CTS Semestre Mayo`}),(0,o.jsx)(`option`,{value:`grati-julio`,children:`Gratificación Fiestas Patrias`}),(0,o.jsx)(`option`,{value:`grati-navidad`,children:`Gratificación Navidad`})]}),(0,o.jsxs)(`select`,{value:m,onChange:e=>h(e.target.value),className:`px-3 py-2 border rounded-lg text-sm bg-sky-50 font-semibold text-sky-800 border-sky-200`,children:[(0,o.jsx)(`option`,{value:`interbank`,children:`Banco TXT: Interbank`}),(0,o.jsx)(`option`,{value:`bcp`,children:`Banco TXT: BCP (Telecrédito)`}),(0,o.jsx)(`option`,{value:`bbva`,children:`Banco TXT: BBVA`})]}),(0,o.jsx)(`button`,{onClick:()=>{if(_.length===0)return;let e=[`DNI`,`Colaborador`,`Régimen`,`Fecha Ingreso`,b,x,`Sueldo + AF (S/.)`,`Detalle Técnico / Criterio`,`Total a Depositar (S/.)`],n=_.map(e=>{let t=y?e.ctsBank||`BCP`:e.salaryBank||e.bank||`BCP`,n=y?e.ctsAccount||`Sin registrar`:e.salaryAccount||e.account||`Sin registrar`;return[`"${e.dni}"`,`"${e.name||e.nombre}"`,`"${e.regimen}"`,`"${e.fechaIngreso}"`,`"${t}"`,`"${n}"`,`"${(e.sueldoComputable||0).toFixed(2)}"`,`"${(e.detalleCalculo||``).replace(/"/g,`""`)}"`,`"${(e.totalPagar||0).toFixed(2)}"`]}),r=[``,``,``,``,``,``,``,`TOTAL GENERAL A DESEMBOLSAR`,v.toFixed(2)],i=[e.join(`;`),...n.map(e=>e.join(`;`)),r.join(`;`)].join(`
`),a=new Blob([`﻿`+i],{type:`text/csv;charset=utf-8;`}),o=URL.createObjectURL(a),c=document.createElement(`a`);c.href=o,c.setAttribute(`download`,`Consolidado_${s.toUpperCase()}_${t.ruc}_${g}.csv`),document.body.appendChild(c),c.click(),document.body.removeChild(c)},disabled:_.length===0,className:`px-3 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-semibold rounded-lg shadow-sm`,children:`Excel`}),(0,o.jsx)(`button`,{onClick:()=>{if(_.length!==0){if(m===`bcp`){let e=_.map(e=>{let t=(y?e.ctsAccount:e.salaryAccount||e.account).replace(/-/g,``).trim(),n=Math.round((e.totalPagar||0)*100).toString().padStart(15,`0`),r=(e.name||e.nombre||``).padEnd(40,` `).slice(0,40),i=e.dni.length===8?`1`:`3`,a=e.dni.padEnd(12,` `);return`D${t.padEnd(20,` `)}S${n}${i}${a}${r}`});S(e.join(`\r
`),`BCP_Telecredito_${t.ruc}.txt`)}else if(m===`interbank`){let e=_.map(e=>{let t=(y?e.ctsAccount:e.salaryAccount||e.account).replace(/-/g,``).trim(),n=(e.totalPagar||0).toFixed(2);return`${e.dni.padEnd(12,` `)}|${t}|${n}|S|${(e.name||e.nombre||``).padEnd(60,` `)}`});S(e.join(`\r
`),`Interbank_Abonos_${t.ruc}.txt`)}else if(m===`bbva`){let e=_.map(e=>`P|${(y?e.ctsAccount:e.salaryAccount||e.account).replace(/-/g,``).trim()}|PEN|${(e.totalPagar||0).toFixed(2)}|${(e.name||e.nombre||``).padEnd(40,` `)}|DNI|${e.dni}`);S(e.join(`\r
`),`BBVA_NetCash_${t.ruc}.txt`)}}},disabled:_.length===0,className:`px-3 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white text-sm font-semibold rounded-lg shadow-sm`,children:`TXT Banco`}),(0,o.jsx)(`button`,{onClick:()=>{if(_.length===0)return;let e=window.open(``,`_blank`);if(!e)return;let n=s===`cts-nov`?`CTS SEMESTRE NOVIEMBRE (MAYO - OCTUBRE)`:s===`cts-may`?`CTS SEMESTRE MAYO (NOVIEMBRE - ABRIL)`:s===`grati-julio`?`GRATIFICACIÓN FIESTAS PATRIAS (JULIO)`:`GRATIFICACIÓN DE NAVIDAD (DICIEMBRE)`,r=`
      <!DOCTYPE html>
      <html lang="es">
      <head>
        <meta charset="UTF-8">
        <title>Consolidado ${s.toUpperCase()} - ${t.name}</title>
        <style>
          @page { size: A4 landscape; margin: 10mm; }
          body { font-family: Arial, sans-serif; font-size: 10px; color: #1e293b; margin: 0; padding: 5px; }
          .header { border-bottom: 2px solid #0284c7; padding-bottom: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: flex-end; }
          .title { font-size: 15px; font-weight: bold; color: #0f172a; margin: 0; }
          .subtitle { font-size: 10px; color: #64748b; margin-top: 2px; }
          .meta { text-align: right; font-size: 9px; color: #475569; }
          table { width: 100%; border-collapse: collapse; margin-top: 8px; }
          th { background-color: #f1f5f9; color: #334155; font-weight: bold; text-align: left; padding: 6px; font-size: 9.5px; border-bottom: 1.5px solid #cbd5e1; }
          td { padding: 6px; border-bottom: 1px solid #e2e8f0; vertical-align: middle; }
          .num { font-family: monospace; text-align: right; }
          .mono { font-family: monospace; }
          .total-row { background-color: #f0f9ff; font-weight: bold; }
          .total-row td { border-top: 2px solid #0284c7; color: #0369a1; font-size: 11px; }
          .signatures { margin-top: 40px; display: flex; justify-content: space-around; text-align: center; font-size: 9px; }
          .line { border-top: 1px solid #94a3b8; width: 180px; margin-bottom: 4px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1 class="title">${t.name}</h1>
            <div class="subtitle">RUC: ${t.ruc} | REPORTE CONSOLIDADO MASIVO DE BENEFICIOS SOCIALES</div>
            <div style="font-weight: bold; margin-top: 4px; color: #0369a1;">${n} - AÑO ${g}</div>
          </div>
          <div class="meta">
            <div>Fecha de Emisión: ${new Date().toLocaleDateString(`es-PE`)}</div>
            <div>Sistema: <strong>Moasist HR</strong></div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th>DNI</th>
              <th>COLABORADOR</th>
              <th>F. INGRESO</th>
              <th>${b.toUpperCase()}</th>
              <th>${x.toUpperCase()}</th>
              <th>SUELDO + AF</th>
              <th>DETALLE TÉCNICO / CRITERIO</th>
              <th style="text-align: right;">TOTAL A DEPOSITAR</th>
            </tr>
          </thead>
          <tbody>
            ${_.map(e=>{let t=y?e.ctsBank||`BCP`:e.salaryBank||e.bank||`BCP`,n=y?e.ctsAccount||`Sin registrar`:e.salaryAccount||e.account||`Sin registrar`;return`
                <tr>
                  <td class="mono">${e.dni}</td>
                  <td><strong>${e.name||e.nombre}</strong></td>
                  <td>${e.fechaIngreso}</td>
                  <td>${t}</td>
                  <td class="mono">${n}</td>
                  <td class="num">S/. ${(e.sueldoComputable||0).toFixed(2)}</td>
                  <td style="font-size: 8.5px; color: #64748b;">${e.detalleCalculo}</td>
                  <td class="num" style="font-weight: bold; color: #0369a1;">S/. ${(e.totalPagar||0).toFixed(2)}</td>
                </tr>
              `}).join(``)}
            <tr class="total-row">
              <td colspan="7" style="text-align: right;">TOTAL GENERAL A DESEMBOLSAR:</td>
              <td class="num">S/. ${v.toFixed(2)}</td>
            </tr>
          </tbody>
        </table>

        <div class="signatures">
          <div>
            <div class="line"></div>
            <div>Elaborado por: Contabilidad / RRHH</div>
          </div>
          <div>
            <div class="line"></div>
            <div>V°B° Gerencia General</div>
          </div>
        </div>

        <script>
          window.onload = function() {
            window.print();
            setTimeout(function() { window.close(); }, 500);
          };
        <\/script>
      </body>
      </html>
    `;e.document.open(),e.document.write(r),e.document.close()},disabled:_.length===0,className:`px-3 py-2 bg-slate-800 hover:bg-slate-900 disabled:opacity-50 text-white text-sm font-semibold rounded-lg shadow-sm`,children:`PDF`})]})]}),(0,o.jsxs)(`div`,{className:`flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-50 p-3 rounded-lg border border-slate-200`,children:[(0,o.jsx)(`div`,{className:`w-full sm:w-72`,children:(0,o.jsx)(`input`,{type:`text`,placeholder:`Buscar por DNI o Colaborador...`,value:l,onChange:e=>u(e.target.value),className:`w-full px-3 py-2 border rounded-lg text-sm bg-white focus:ring-2 focus:ring-sky-500`})}),(0,o.jsx)(`div`,{className:`w-full sm:w-64`,children:(0,o.jsxs)(`select`,{value:d,onChange:e=>f(e.target.value),className:`w-full px-3 py-2 border rounded-lg text-sm bg-white focus:ring-2 focus:ring-sky-500`,children:[(0,o.jsx)(`option`,{value:`todas`,children:`Todas las Áreas`}),n.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]})})]}),(0,o.jsx)(`div`,{className:`overflow-x-auto`,children:(0,o.jsxs)(`table`,{className:`w-full text-left border-collapse text-sm`,children:[(0,o.jsx)(`thead`,{children:(0,o.jsxs)(`tr`,{className:`bg-slate-100 text-slate-700 border-b`,children:[(0,o.jsx)(`th`,{className:`p-3 font-semibold`,children:`DNI`}),(0,o.jsx)(`th`,{className:`p-3 font-semibold`,children:`Colaborador`}),(0,o.jsx)(`th`,{className:`p-3 font-semibold`,children:`Régimen`}),(0,o.jsx)(`th`,{className:`p-3 font-semibold`,children:`F. Ingreso`}),(0,o.jsx)(`th`,{className:`p-3 font-semibold`,children:b}),(0,o.jsx)(`th`,{className:`p-3 font-semibold`,children:x}),(0,o.jsx)(`th`,{className:`p-3 font-semibold`,children:`Sueldo + AF (S/.)`}),(0,o.jsx)(`th`,{className:`p-3 font-semibold`,children:`Detalle Técnico`}),(0,o.jsx)(`th`,{className:`p-3 font-semibold text-right`,children:`Total a Depositar (S/.)`})]})}),(0,o.jsx)(`tbody`,{className:`divide-y divide-slate-200`,children:_.length===0?(0,o.jsx)(`tr`,{children:(0,o.jsx)(`td`,{colSpan:9,className:`text-center py-8 text-slate-400`,children:`No se encontraron colaboradores que coincidan con la búsqueda.`})}):_.map(e=>{let t=y?e.ctsBank||`BCP`:e.salaryBank||e.bank||`BCP`,n=y?e.ctsAccount||`Sin registrar`:e.salaryAccount||e.account||`Sin registrar`;return(0,o.jsxs)(`tr`,{className:`hover:bg-slate-50 transition-colors`,children:[(0,o.jsx)(`td`,{className:`p-3 font-mono text-slate-600`,children:e.dni}),(0,o.jsx)(`td`,{className:`p-3 font-medium text-slate-900`,children:e.name||e.nombre||`Sin Nombre`}),(0,o.jsx)(`td`,{className:`p-3 text-slate-600`,children:e.regimen}),(0,o.jsx)(`td`,{className:`p-3 text-slate-600`,children:e.fechaIngreso}),(0,o.jsx)(`td`,{className:`p-3 text-slate-700 font-medium`,children:(0,o.jsx)(`span`,{className:`px-2 py-0.5 rounded bg-slate-100 text-xs border border-slate-200`,children:t})}),(0,o.jsx)(`td`,{className:`p-3 font-mono text-xs text-slate-700`,children:n}),(0,o.jsxs)(`td`,{className:`p-3 font-mono text-slate-800`,children:[`S/. `,(e.sueldoComputable||0).toFixed(2)]}),(0,o.jsx)(`td`,{className:`p-3 text-xs text-slate-500`,children:e.detalleCalculo}),(0,o.jsxs)(`td`,{className:`p-3 font-mono font-bold text-sky-700 text-right`,children:[`S/. `,(e.totalPagar||0).toFixed(2)]})]},e.dni)})})]})}),(0,o.jsxs)(`div`,{className:`flex justify-between items-center bg-sky-50 p-4 rounded-lg border border-sky-100`,children:[(0,o.jsx)(`span`,{className:`font-semibold text-sky-900`,children:`Monto Total Consolidado a Desembolsar (Filtrado):`}),(0,o.jsxs)(`span`,{className:`font-mono text-xl font-bold text-sky-800`,children:[`S/. `,v.toFixed(2)]})]})]})}function c(){return(0,o.jsxs)(`div`,{className:`space-y-6`,children:[(0,o.jsxs)(`div`,{className:`flex flex-col gap-1`,children:[(0,o.jsx)(`h1`,{className:`text-2xl font-bold tracking-tight text-slate-900`,children:`Módulo Consolidado Masivo`}),(0,o.jsx)(`p`,{className:`text-sm text-slate-500`,children:`Cálculo automatizado y simultáneo de CTS y Gratificaciones legales para todo el personal de la empresa bajo normativa peruana.`})]}),(0,o.jsx)(s,{})]})}export{c as component};