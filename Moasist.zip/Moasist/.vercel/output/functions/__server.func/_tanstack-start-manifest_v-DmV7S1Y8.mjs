// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DmV7S1Y8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/__root.tsx",
		children: [
			"/",
			"/asistencia",
			"/colaboradores",
			"/consolidado",
			"/consolidado-asistencia",
			"/documentos",
			"/empresa",
			"/organizacion",
			"/planilla",
			"/vacaciones"
		],
		preloads: ["/assets/index-Pkbx6dum.js", "/assets/jsx-runtime-BVQXJMCF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Pkbx6dum.js"
		} }]
	},
	"/": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-aim45Kg0.js",
			"/assets/store-CjYBk8gJ.js",
			"/assets/shell-Dt29QQEi.js",
			"/assets/access-DdiyTOuY.js",
			"/assets/useOfflineSync-hgKgUA8Q.js"
		]
	},
	"/asistencia": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/asistencia.tsx",
		children: void 0,
		preloads: [
			"/assets/asistencia-Nvac-58F.js",
			"/assets/shell-Dt29QQEi.js",
			"/assets/access-DdiyTOuY.js",
			"/assets/store-CjYBk8gJ.js",
			"/assets/useOfflineSync-hgKgUA8Q.js"
		]
	},
	"/colaboradores": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/colaboradores.tsx",
		children: ["/colaboradores/$id"],
		preloads: [
			"/assets/colaboradores-DPogTsEB.js",
			"/assets/shell-Dt29QQEi.js",
			"/assets/employee-form-Dr8WZ9hm.js",
			"/assets/access-DdiyTOuY.js",
			"/assets/store-CjYBk8gJ.js"
		]
	},
	"/consolidado": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/consolidado.tsx",
		children: void 0,
		preloads: ["/assets/consolidado-DtgoacqX.js", "/assets/store-CjYBk8gJ.js"]
	},
	"/consolidado-asistencia": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/consolidado-asistencia.tsx",
		children: void 0,
		preloads: [
			"/assets/consolidado-asistencia-COLhFusZ.js",
			"/assets/shell-Dt29QQEi.js",
			"/assets/store-CjYBk8gJ.js"
		]
	},
	"/documentos": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/documentos.tsx",
		children: void 0,
		preloads: [
			"/assets/documentos-jdDqnZPp.js",
			"/assets/shell-Dt29QQEi.js",
			"/assets/boleta-D_VvTjiC.js",
			"/assets/access-DdiyTOuY.js",
			"/assets/store-CjYBk8gJ.js"
		]
	},
	"/empresa": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/empresa.tsx",
		children: void 0,
		preloads: [
			"/assets/empresa-DsScrDS9.js",
			"/assets/shell-Dt29QQEi.js",
			"/assets/store-CjYBk8gJ.js"
		]
	},
	"/organizacion": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/organizacion.tsx",
		children: void 0,
		preloads: [
			"/assets/organizacion-DViwufxf.js",
			"/assets/shell-Dt29QQEi.js",
			"/assets/store-CjYBk8gJ.js"
		]
	},
	"/planilla": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/planilla.tsx",
		children: void 0,
		preloads: [
			"/assets/planilla-6IF0SX1s.js",
			"/assets/shell-Dt29QQEi.js",
			"/assets/boleta-D_VvTjiC.js",
			"/assets/access-DdiyTOuY.js",
			"/assets/store-CjYBk8gJ.js"
		]
	},
	"/vacaciones": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/vacaciones.tsx",
		children: void 0,
		preloads: [
			"/assets/vacaciones-C1yTdigS.js",
			"/assets/shell-Dt29QQEi.js",
			"/assets/access-DdiyTOuY.js",
			"/assets/store-CjYBk8gJ.js"
		]
	},
	"/colaboradores/$id": {
		filePath: "D:/Documentos/Downloads/PROYECTO INMOA/MOASIST/grok-workspace (1)/src/routes/colaboradores.$id.tsx",
		children: void 0,
		preloads: ["/assets/colaboradores._id-DIAHY7-D.js", "/assets/boleta-D_VvTjiC.js"]
	}
} });
export { tsrStartManifest };
