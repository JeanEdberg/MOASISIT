// node_modules/.nitro/vite/services/ssr/assets/access-CMOdfdyo.js
function directReports(employees, managerId) {
	return employees.filter((e) => e.managerId === managerId);
}
function visibleEmployees(employees, viewer) {
	if (!viewer.employeeId && viewer.mode !== "rrhh") return [];
	if (viewer.mode === "rrhh") return employees;
	if (viewer.mode === "colaborador") return employees.filter((e) => e.id === viewer.employeeId);
	const ids = /* @__PURE__ */ new Set([viewer.employeeId, ...directReports(employees, viewer.employeeId).map((e) => e.id)]);
	return employees.filter((e) => ids.has(e.id));
}
function canSeeMoney(viewer, employeeId) {
	if (viewer.mode === "rrhh") return true;
	return viewer.mode === "colaborador" && viewer.employeeId === employeeId;
}
function canApprove(viewer, employees, employeeId) {
	if (viewer.mode === "colaborador") return false;
	if (viewer.employeeId === employeeId) return viewer.mode === "rrhh";
	if (viewer.mode === "rrhh") return true;
	return employees.some((e) => e.id === employeeId && e.managerId === viewer.employeeId);
}
export { canSeeMoney as n, visibleEmployees as r, canApprove as t };
