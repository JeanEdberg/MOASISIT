import { i as __toESM } from "../_runtime.mjs";
import { O as useHr, u as calcularConsolidadoMasivo } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/consolidado-kPwULF_S.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ConsolidadoMasivoView() {
	const { employees, company, areas } = useHr();
	const [tipoBeneficio, setTipoBeneficio] = (0, import_react.useState)("cts-nov");
	const [busqueda, setBusqueda] = (0, import_react.useState)("");
	const [areaFiltro, setAreaFiltro] = (0, import_react.useState)("todas");
	const bancoPorDefecto = company.id === "inmoa" ? "interbank" : company.id === "7pollitos" ? "bbva" : "bcp";
	const [bancoExportacion, setBancoExportacion] = (0, import_react.useState)(bancoPorDefecto);
	const anioActual = (/* @__PURE__ */ new Date()).getFullYear();
	const consolidado = calcularConsolidadoMasivo(employees, company, tipoBeneficio, anioActual).filter((item) => {
		const empOriginal = employees.find((e) => e.dni === item.dni);
		const coincideTexto = item.dni.toLowerCase().includes(busqueda.toLowerCase()) || (item.name || item.nombre || "").toLowerCase().includes(busqueda.toLowerCase());
		const coincideArea = areaFiltro === "todas" || empOriginal && empOriginal.areaId === areaFiltro;
		return coincideTexto && coincideArea;
	});
	const totalGeneral = consolidado.reduce((acc, item) => acc + item.totalPagar, 0);
	const esCts = tipoBeneficio.includes("cts");
	const etiquetaBanco = esCts ? "Banco CTS" : "Banco Sueldo";
	const etiquetaCuenta = esCts ? "N° Cuenta CTS" : "N° Cuenta Sueldo";
	const descargarArchivoTxt = (contenido, nombreArchivo) => {
		const blob = new Blob([contenido], { type: "text/plain;charset=utf-8;" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.setAttribute("download", nombreArchivo);
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	};
	const exportarTxtBanco = () => {
		if (consolidado.length === 0) return;
		if (bancoExportacion === "bcp") {
			const lineas = consolidado.map((item) => {
				const cta = (esCts ? item.ctsAccount : item.salaryAccount || item.account).replace(/-/g, "").trim();
				const montoCentavos = Math.round((item.totalPagar || 0) * 100).toString().padStart(15, "0");
				const nombre = (item.name || item.nombre || "").padEnd(40, " ").slice(0, 40);
				const tipoDoc = item.dni.length === 8 ? "1" : "3";
				const nroDoc = item.dni.padEnd(12, " ");
				return `D${cta.padEnd(20, " ")}S${montoCentavos}${tipoDoc}${nroDoc}${nombre}`;
			});
			descargarArchivoTxt(lineas.join("\r\n"), `BCP_Telecredito_${company.ruc}.txt`);
		} else if (bancoExportacion === "interbank") {
			const lineas = consolidado.map((item) => {
				const cta = (esCts ? item.ctsAccount : item.salaryAccount || item.account).replace(/-/g, "").trim();
				const monto = (item.totalPagar || 0).toFixed(2);
				return `${item.dni.padEnd(12, " ")}|${cta}|${monto}|S|${(item.name || item.nombre || "").padEnd(60, " ")}`;
			});
			descargarArchivoTxt(lineas.join("\r\n"), `Interbank_Abonos_${company.ruc}.txt`);
		} else if (bancoExportacion === "bbva") {
			const lineas = consolidado.map((item) => {
				return `P|${(esCts ? item.ctsAccount : item.salaryAccount || item.account).replace(/-/g, "").trim()}|PEN|${(item.totalPagar || 0).toFixed(2)}|${(item.name || item.nombre || "").padEnd(40, " ")}|DNI|${item.dni}`;
			});
			descargarArchivoTxt(lineas.join("\r\n"), `BBVA_NetCash_${company.ruc}.txt`);
		}
	};
	const exportarAExcel = () => {
		if (consolidado.length === 0) return;
		const cabeceras = [
			"DNI",
			"Colaborador",
			"Régimen",
			"Fecha Ingreso",
			etiquetaBanco,
			etiquetaCuenta,
			"Sueldo + AF (S/.)",
			"Detalle Técnico / Criterio",
			"Total a Depositar (S/.)"
		];
		const filas = consolidado.map((item) => {
			const bnc = esCts ? item.ctsBank || "BCP" : item.salaryBank || item.bank || "BCP";
			const cta = esCts ? item.ctsAccount || "Sin registrar" : item.salaryAccount || item.account || "Sin registrar";
			return [
				`"${item.dni}"`,
				`"${item.name || item.nombre}"`,
				`"${item.regimen}"`,
				`"${item.fechaIngreso}"`,
				`"${bnc}"`,
				`"${cta}"`,
				`"${(item.sueldoComputable || 0).toFixed(2)}"`,
				`"${(item.detalleCalculo || "").replace(/"/g, "\"\"")}"`,
				`"${(item.totalPagar || 0).toFixed(2)}"`
			];
		});
		const filaTotal = [
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"TOTAL GENERAL A DESEMBOLSAR",
			totalGeneral.toFixed(2)
		];
		const contenidoCsv = [
			cabeceras.join(";"),
			...filas.map((f) => f.join(";")),
			filaTotal.join(";")
		].join("\n");
		const blob = new Blob(["﻿" + contenidoCsv], { type: "text/csv;charset=utf-8;" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.setAttribute("download", `Consolidado_${tipoBeneficio.toUpperCase()}_${company.ruc}_${anioActual}.csv`);
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	};
	const exportarAPDF = () => {
		if (consolidado.length === 0) return;
		const printWindow = window.open("", "_blank");
		if (!printWindow) return;
		const tituloBeneficio = tipoBeneficio === "cts-nov" ? "CTS SEMESTRE NOVIEMBRE (MAYO - OCTUBRE)" : tipoBeneficio === "cts-may" ? "CTS SEMESTRE MAYO (NOVIEMBRE - ABRIL)" : tipoBeneficio === "grati-julio" ? "GRATIFICACIÓN FIESTAS PATRIAS (JULIO)" : "GRATIFICACIÓN DE NAVIDAD (DICIEMBRE)";
		const htmlContent = `
      <!DOCTYPE html>
      <html lang="es">
      <head>
        <meta charset="UTF-8">
        <title>Consolidado ${tipoBeneficio.toUpperCase()} - ${company.name}</title>
        <style>
          @page { size: A4 landscape; margin: 10mm; }
          body { font-family: Arial, sans-serif; font-size: 10px; color: #1e293b; margin: 0; padding: 5px; }
          .header { border-bottom: 2px solid #0284c7; padding-bottom: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: flex-end; }
          .title { font-size: 15px; font-weight: bold; color: #0f172a; margin: 0; }
          .subtitle { font-size: 10px; color: #64748b; margin-top: 2px; }
          .meta { text-align: right; font-size: 9px; color: #475569; }
          table { width: 100%; border-collapse: collapse; margin-top: 8px; }
          th { background-color: #f1f5f9; color: #334155; font-weight: bold; text-align: left; padding: 6px; font-size: 9.5px; border-bottom: 1.5px solid #cbd5e1; }
          td { padding: 6px; border-bottom: 1px solid #e2e8f0; vertical-align: middle; }
          .num { font-family: monospace; text-align: right; }
          .mono { font-family: monospace; }
          .total-row { background-color: #f0f9ff; font-weight: bold; }
          .total-row td { border-top: 2px solid #0284c7; color: #0369a1; font-size: 11px; }
          .signatures { margin-top: 40px; display: flex; justify-content: space-around; text-align: center; font-size: 9px; }
          .line { border-top: 1px solid #94a3b8; width: 180px; margin-bottom: 4px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1 class="title">${company.name}</h1>
            <div class="subtitle">RUC: ${company.ruc} | REPORTE CONSOLIDADO MASIVO DE BENEFICIOS SOCIALES</div>
            <div style="font-weight: bold; margin-top: 4px; color: #0369a1;">${tituloBeneficio} - AÑO ${anioActual}</div>
          </div>
          <div class="meta">
            <div>Fecha de Emisión: ${(/* @__PURE__ */ new Date()).toLocaleDateString("es-PE")}</div>
            <div>Sistema: <strong>Moasist HR</strong></div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th>DNI</th>
              <th>COLABORADOR</th>
              <th>F. INGRESO</th>
              <th>${etiquetaBanco.toUpperCase()}</th>
              <th>${etiquetaCuenta.toUpperCase()}</th>
              <th>SUELDO + AF</th>
              <th>DETALLE TÉCNICO / CRITERIO</th>
              <th style="text-align: right;">TOTAL A DEPOSITAR</th>
            </tr>
          </thead>
          <tbody>
            ${consolidado.map((item) => {
			const bnc = esCts ? item.ctsBank || "BCP" : item.salaryBank || item.bank || "BCP";
			const cta = esCts ? item.ctsAccount || "Sin registrar" : item.salaryAccount || item.account || "Sin registrar";
			return `
                <tr>
                  <td class="mono">${item.dni}</td>
                  <td><strong>${item.name || item.nombre}</strong></td>
                  <td>${item.fechaIngreso}</td>
                  <td>${bnc}</td>
                  <td class="mono">${cta}</td>
                  <td class="num">S/. ${(item.sueldoComputable || 0).toFixed(2)}</td>
                  <td style="font-size: 8.5px; color: #64748b;">${item.detalleCalculo}</td>
                  <td class="num" style="font-weight: bold; color: #0369a1;">S/. ${(item.totalPagar || 0).toFixed(2)}</td>
                </tr>
              `;
		}).join("")}
            <tr class="total-row">
              <td colspan="7" style="text-align: right;">TOTAL GENERAL A DESEMBOLSAR:</td>
              <td class="num">S/. ${totalGeneral.toFixed(2)}</td>
            </tr>
          </tbody>
        </table>

        <div class="signatures">
          <div>
            <div class="line"></div>
            <div>Elaborado por: Contabilidad / RRHH</div>
          </div>
          <div>
            <div class="line"></div>
            <div>V°B° Gerencia General</div>
          </div>
        </div>

        <script>
          window.onload = function() {
            window.print();
            setTimeout(function() { window.close(); }, 500);
          };
        <\/script>
      </body>
      </html>
    `;
		printWindow.document.open();
		printWindow.document.write(htmlContent);
		printWindow.document.close();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 bg-white rounded-xl shadow-sm border border-slate-200 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900",
					children: "Consolidado Masivo de Beneficios Sociales"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-slate-500",
					children: [
						company.name,
						" — RUC: ",
						company.ruc
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: tipoBeneficio,
							onChange: (e) => setTipoBeneficio(e.target.value),
							className: "px-3 py-2 border rounded-lg text-sm bg-slate-50 font-medium text-slate-700",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "cts-nov",
									children: "CTS Semestre Noviembre"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "cts-may",
									children: "CTS Semestre Mayo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "grati-julio",
									children: "Gratificación Fiestas Patrias"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "grati-navidad",
									children: "Gratificación Navidad"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: bancoExportacion,
							onChange: (e) => setBancoExportacion(e.target.value),
							className: "px-3 py-2 border rounded-lg text-sm bg-sky-50 font-semibold text-sky-800 border-sky-200",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "interbank",
									children: "Banco TXT: Interbank"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "bcp",
									children: "Banco TXT: BCP (Telecrédito)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "bbva",
									children: "Banco TXT: BBVA"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: exportarAExcel,
							disabled: consolidado.length === 0,
							className: "px-3 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-semibold rounded-lg shadow-sm",
							children: "Excel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: exportarTxtBanco,
							disabled: consolidado.length === 0,
							className: "px-3 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white text-sm font-semibold rounded-lg shadow-sm",
							children: "TXT Banco"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: exportarAPDF,
							disabled: consolidado.length === 0,
							className: "px-3 py-2 bg-slate-800 hover:bg-slate-900 disabled:opacity-50 text-white text-sm font-semibold rounded-lg shadow-sm",
							children: "PDF"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-50 p-3 rounded-lg border border-slate-200",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-full sm:w-72",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						placeholder: "Buscar por DNI o Colaborador...",
						value: busqueda,
						onChange: (e) => setBusqueda(e.target.value),
						className: "w-full px-3 py-2 border rounded-lg text-sm bg-white focus:ring-2 focus:ring-sky-500"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-full sm:w-64",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: areaFiltro,
						onChange: (e) => setAreaFiltro(e.target.value),
						className: "w-full px-3 py-2 border rounded-lg text-sm bg-white focus:ring-2 focus:ring-sky-500",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "todas",
							children: "Todas las Áreas"
						}), areas.map((area) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: area.id,
							children: area.name
						}, area.id))]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left border-collapse text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "bg-slate-100 text-slate-700 border-b",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 font-semibold",
								children: "DNI"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 font-semibold",
								children: "Colaborador"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 font-semibold",
								children: "Régimen"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 font-semibold",
								children: "F. Ingreso"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 font-semibold",
								children: etiquetaBanco
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 font-semibold",
								children: etiquetaCuenta
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 font-semibold",
								children: "Sueldo + AF (S/.)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 font-semibold",
								children: "Detalle Técnico"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 font-semibold text-right",
								children: "Total a Depositar (S/.)"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-slate-200",
						children: consolidado.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 9,
							className: "text-center py-8 text-slate-400",
							children: "No se encontraron colaboradores que coincidan con la búsqueda."
						}) }) : consolidado.map((item) => {
							const bnc = esCts ? item.ctsBank || "BCP" : item.salaryBank || item.bank || "BCP";
							const cta = esCts ? item.ctsAccount || "Sin registrar" : item.salaryAccount || item.account || "Sin registrar";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-slate-50 transition-colors",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 font-mono text-slate-600",
										children: item.dni
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 font-medium text-slate-900",
										children: item.name || item.nombre || "Sin Nombre"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 text-slate-600",
										children: item.regimen
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 text-slate-600",
										children: item.fechaIngreso
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 text-slate-700 font-medium",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "px-2 py-0.5 rounded bg-slate-100 text-xs border border-slate-200",
											children: bnc
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 font-mono text-xs text-slate-700",
										children: cta
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "p-3 font-mono text-slate-800",
										children: ["S/. ", (item.sueldoComputable || 0).toFixed(2)]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 text-xs text-slate-500",
										children: item.detalleCalculo
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "p-3 font-mono font-bold text-sky-700 text-right",
										children: ["S/. ", (item.totalPagar || 0).toFixed(2)]
									})
								]
							}, item.dni);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between items-center bg-sky-50 p-4 rounded-lg border border-sky-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold text-sky-900",
					children: "Monto Total Consolidado a Desembolsar (Filtrado):"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-xl font-bold text-sky-800",
					children: ["S/. ", totalGeneral.toFixed(2)]
				})]
			})
		]
	});
}
function ConsolidadoPageRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold tracking-tight text-slate-900",
				children: "Módulo Consolidado Masivo"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-slate-500",
				children: "Cálculo automatizado y simultáneo de CTS y Gratificaciones legales para todo el personal de la empresa bajo normativa peruana."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsolidadoMasivoView, {})]
	});
}
export { ConsolidadoPageRoute as component };
