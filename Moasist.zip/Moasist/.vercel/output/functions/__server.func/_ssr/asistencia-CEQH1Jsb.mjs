import { i as __toESM } from "../_runtime.mjs";
import { a as Modal, c as fieldClass, i as Field, n as Button, o as PageHeader, s as Shell, t as Badge } from "./shell-DnMRrmUQ.mjs";
import { r as visibleEmployees } from "./access-CMOdfdyo.mjs";
import { E as shortDate, O as useHr, m as fullName, t as ATTENDANCE_LABEL } from "./store-BbW2cja4.mjs";
import { n as useOfflineSync, t as guardarAsistenciaOffline } from "./useOfflineSync-C_zBBdYp.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
// node_modules/.nitro/vite/services/ssr/assets/asistencia-CEQH1Jsb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var OFICINA_CENTRAL = {
	lat: -12.5933,
	lon: -69.1891
};
var RADIO_TOLERANCIA_METROS = 150;
/**
* Calcula la distancia en metros entre dos puntos geográficos usando la fórmula Haversine.
*/
function calcularDistanciaMetros(lat1, lon1, lat2, lon2) {
	const R = 6371e3;
	const dLat = (lat2 - lat1) * (Math.PI / 180);
	const dLon = (lon2 - lon1) * (Math.PI / 180);
	const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
	return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}
/**
* Valida el fichaje de asistencia según la modalidad laboral (workMode) del colaborador.
*/
function validarYRegistrarAsistencia(employee, ubicacionActual) {
	if (employee.workMode === "itinerante") return {
		aprobado: true,
		kind: "remoto",
		mensaje: "Marcación registrada en Modo Itinerante / Viajero (Bypass geográfico autorizado)."
	};
	if (employee.workMode === "virtual") return {
		aprobado: true,
		kind: "remoto",
		mensaje: "Marcación remota aprobada correctamente."
	};
	if (employee.workMode === "campo") return {
		aprobado: true,
		kind: "presente",
		mensaje: "Marcación de campo / galpón registrada (Sincronización local)."
	};
	if (!ubicacionActual) return {
		aprobado: false,
		kind: "falta",
		mensaje: "Se requiere activar el GPS de tu dispositivo para validar tu ubicación en oficina central."
	};
	const distancia = Math.round(calcularDistanciaMetros(ubicacionActual.lat, ubicacionActual.lon, OFICINA_CENTRAL.lat, OFICINA_CENTRAL.lon));
	if (distancia <= RADIO_TOLERANCIA_METROS) return {
		aprobado: true,
		kind: "presente",
		mensaje: `Asistencia presencial validada con éxito (A ${distancia}m de la oficina central).`,
		distanciaMetros: distancia
	};
	else return {
		aprobado: false,
		kind: "falta",
		mensaje: `Fuera de rango geográfico. Estás a ${distancia}m de la oficina central (Radio permitido: ${RADIO_TOLERANCIA_METROS}m).`,
		distanciaMetros: distancia
	};
}
function AttendanceView() {
	const { employees, viewer, upsertAttendance } = useHr();
	const { sincronizando, pendientesCount, sincronizarPendientes } = useOfflineSync();
	const empleadoActual = employees.find((e) => e.id === viewer.employeeId) || employees[0];
	const [cargandoGPS, setCargandoGPS] = (0, import_react.useState)(false);
	const [resultado, setResultado] = (0, import_react.useState)(null);
	const hoyStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
	const handleMarcarAsistencia = (tipoAccion) => {
		setCargandoGPS(true);
		setResultado(null);
		if (!(empleadoActual.workMode === "presencial" || empleadoActual.workMode === "hibrido")) {
			const evaluacion = validarYRegistrarAsistencia(empleadoActual);
			procesarRegistro(evaluacion, tipoAccion);
			return;
		}
		if (!navigator.geolocation) {
			alert("Tu dispositivo no soporta geolocalización GPS.");
			setCargandoGPS(false);
			return;
		}
		navigator.geolocation.getCurrentPosition((position) => {
			const ubicacionActual = {
				lat: position.coords.latitude,
				lon: position.coords.longitude
			};
			const evaluacion = validarYRegistrarAsistencia(empleadoActual, ubicacionActual);
			procesarRegistro(evaluacion, tipoAccion);
		}, (error) => {
			alert("No se pudo obtener la ubicación GPS. Verifica los permisos de ubicación en tu dispositivo.");
			setCargandoGPS(false);
		}, {
			enableHighAccuracy: true,
			timeout: 1e4,
			maximumAge: 0
		});
	};
	const procesarRegistro = async (evaluacion, tipoAccion) => {
		setCargandoGPS(false);
		if (evaluacion.aprobado) {
			const horaActual = (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit",
				hour12: false
			});
			const nuevoRegistro = {
				id: `${empleadoActual.id}-${hoyStr}`,
				employeeId: empleadoActual.id,
				date: hoyStr,
				kind: evaluacion.kind,
				checkIn: tipoAccion === "entrada" ? horaActual : "08:30",
				checkOut: tipoAccion === "salida" ? horaActual : "18:00",
				extra25: 0,
				extra35: 0
			};
			if (!navigator.onLine) {
				await guardarAsistenciaOffline(nuevoRegistro);
				setResultado({
					aprobado: true,
					mensaje: "📡 Registrado en modo offline. Guardado localmente en IndexedDB."
				});
			} else {
				upsertAttendance(nuevoRegistro);
				setResultado({
					aprobado: evaluacion.aprobado,
					mensaje: evaluacion.mensaje
				});
			}
		} else setResultado({
			aprobado: false,
			mensaje: evaluacion.mensaje
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 bg-white rounded-xl shadow-sm border border-slate-200 max-w-xl mx-auto space-y-6",
		children: [
			pendientesCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-center justify-between text-xs text-amber-800",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "relative flex h-2.5 w-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Tienes ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: pendientesCount }),
						" marcación(es) pendientes de sincronizar."
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: sincronizarPendientes,
					disabled: sincronizando || !navigator.onLine,
					className: "px-2 py-1 bg-amber-600 text-white rounded font-semibold hover:bg-amber-700 disabled:opacity-50 cursor-pointer",
					children: sincronizando ? "Sincronizando..." : "Sincronizar ahora"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b pb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold text-slate-900",
						children: "Control de Asistencia Biométrico / GPS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-slate-500",
						children: ["Colaborador: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold text-slate-700",
							children: [
								empleadoActual.names,
								" ",
								empleadoActual.paternal
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-sky-50 text-sky-700 border border-sky-200",
						children: ["Modalidad asignada: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "uppercase",
							children: empleadoActual.workMode
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => handleMarcarAsistencia("entrada"),
					disabled: cargandoGPS,
					className: "p-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-xl shadow-sm transition-all flex flex-col items-center justify-center gap-2 cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-2xl",
						children: "📥"
					}), cargandoGPS ? "Obteniendo GPS..." : "Marcar Ingreso"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => handleMarcarAsistencia("salida"),
					disabled: cargandoGPS,
					className: "p-4 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold rounded-xl shadow-sm transition-all flex flex-col items-center justify-center gap-2 cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-2xl",
						children: "📤"
					}), cargandoGPS ? "Obteniendo GPS..." : "Marcar Salida"]
				})]
			}),
			resultado && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-4 rounded-xl text-sm font-medium border ${resultado.aprobado ? "bg-emerald-50 text-emerald-800 border-emerald-200" : "bg-red-50 text-red-800 border-red-200"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-bold mb-1",
					children: resultado.aprobado ? "✅ Registro Exitoso" : "❌ Marcación Denegada"
				}), resultado.mensaje]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-xs text-slate-400 text-center pt-2 border-t",
				children: [
					"Fecha del sistema: ",
					hoyStr,
					" | Moasist Geofencing Engine v2.6"
				]
			})
		]
	});
}
var KINDS = Object.keys(ATTENDANCE_LABEL);
function AttendancePage() {
	const data = useHr();
	const upsert = useHr((s) => s.upsertAttendance);
	const people = visibleEmployees(data.employees, data.viewer).filter((e) => e.status === "activo");
	const ids = new Set(people.map((e) => e.id));
	const marks = (0, import_react.useMemo)(() => data.attendance.filter((a) => ids.has(a.employeeId)).sort((a, b) => b.date.localeCompare(a.date) || a.employeeId.localeCompare(b.employeeId)), [data.attendance, ids]);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		employeeId: data.viewer.employeeId || people[0]?.id || "",
		date: "2026-11-06",
		kind: "presente",
		checkIn: "09:00",
		checkOut: "18:00",
		extra: "0"
	});
	const faltas = marks.filter((m) => m.kind === "falta").length;
	const tardanzas = marks.filter((m) => m.kind === "tardanza").length;
	const extras = marks.reduce((s, m) => s + m.extra25 + m.extra35, 0);
	const closed = Boolean(data.snapshots[form.date.slice(0, 7)]);
	const save = () => {
		if (!form.employeeId || !form.date) return;
		if (data.snapshots[form.date.slice(0, 7)]) {
			toast.error("Ese periodo ya está cerrado");
			return;
		}
		const hours = Math.max(0, Number(form.extra) || 0);
		const extra25 = Math.min(2, hours);
		const extra35 = Math.max(0, hours - 2);
		const absent = form.kind === "falta";
		upsert({
			id: `${form.employeeId}-${form.date}`,
			employeeId: form.employeeId,
			date: form.date,
			kind: form.kind,
			checkIn: absent ? "" : form.checkIn,
			checkOut: absent ? "" : form.checkOut,
			extra25: absent ? 0 : extra25,
			extra35: absent ? 0 : extra35
		});
		setOpen(false);
		toast.success("Marcación guardada");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Jornada",
			title: "Asistencia",
			lede: "La semana del 2 al 6 de noviembre ya tiene marcas. Una falta descuenta un treintavo; las dos primeras horas extra van al 25% y el resto al 35%.",
			actions: data.viewer.mode !== "colaborador" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(true),
				children: "Registrar día"
			}) : void 0
		}),
		data.viewer.mode === "colaborador" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttendanceView, {})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Faltas",
					value: String(faltas)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Tardanzas",
					value: String(tardanzas)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Horas extra",
					value: String(extras)
				})
			]
		}),
		marks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-lg border border-dashed border-line bg-surface px-4 py-8 text-center text-sm text-muted",
			children: "No hay marcas en esta vista."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-lg border border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-max min-w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Fecha"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Colaborador"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Estado"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Horario"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Extra"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: marks.map((m) => {
					const who = data.employees.find((e) => e.id === m.employeeId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: shortDate(m.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: who ? fullName(who) : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: m.kind === "falta" ? "clay" : m.kind === "tardanza" ? "ink" : "line",
									children: ATTENDANCE_LABEL[m.kind]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "num px-4 py-3",
								children: m.checkIn ? `${m.checkIn} – ${m.checkOut}` : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "num px-4 py-3",
								children: m.extra25 + m.extra35 || "—"
							})
						]
					}, m.id);
				}) })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			title: "Registrar marcación",
			onClose: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Colaborador",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: form.employeeId,
							onChange: (e) => setForm({
								...form,
								employeeId: e.target.value
							}),
							children: people.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: e.id,
								children: fullName(e)
							}, e.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Fecha",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "date",
							value: form.date,
							onChange: (e) => setForm({
								...form,
								date: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Estado",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: form.kind,
							onChange: (e) => setForm({
								...form,
								kind: e.target.value
							}),
							children: KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: k,
								children: ATTENDANCE_LABEL[k]
							}, k))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Entrada",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: form.checkIn,
								onChange: (e) => setForm({
									...form,
									checkIn: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Salida",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: form.checkOut,
								onChange: (e) => setForm({
									...form,
									checkOut: e.target.value
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Horas extra del día",
						hint: "Hasta 2 horas al 25%, el resto al 35%.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							inputMode: "decimal",
							value: form.extra,
							onChange: (e) => setForm({
								...form,
								extra: e.target.value
							})
						})
					}),
					closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-clay",
						children: "La planilla de ese mes está cerrada. Reábrela para corregir marcas."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: save,
						disabled: closed,
						children: "Guardar marca"
					})
				]
			})
		})
	] });
}
function Mini({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "num mt-1 font-display text-2xl",
			children: value
		})]
	});
}
export { AttendancePage as component };
