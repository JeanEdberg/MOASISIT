import { i as differenceInCalendarDays, n as format, r as differenceInMonths, t as es } from "../_libs/date-fns.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
// node_modules/.nitro/vite/services/ssr/assets/store-BbW2cja4.js
var HOY = "2026-11-08";
var MONTHS = [
	"enero",
	"febrero",
	"marzo",
	"abril",
	"mayo",
	"junio",
	"julio",
	"agosto",
	"septiembre",
	"octubre",
	"noviembre",
	"diciembre"
];
function inkFor(hex) {
	const raw = hex.replace("#", "");
	if (!/^[0-9a-fA-F]{6}$/.test(raw)) return "#fff7f2";
	const r = parseInt(raw.slice(0, 2), 16);
	const g = parseInt(raw.slice(2, 4), 16);
	const b = parseInt(raw.slice(4, 6), 16);
	return (.299 * r + .587 * g + .114 * b) / 255 > .64 ? "#1e1a16" : "#fff7f2";
}
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}
function parseDay(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y, (m ?? 1) - 1, d ?? 1);
}
function isoDay(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function periodLabel(period) {
	const [y, m] = period.split("-").map(Number);
	const name = MONTHS[(m ?? 1) - 1] ?? period;
	return `${name.charAt(0).toUpperCase()}${name.slice(1)} ${y}`;
}
function longDate(iso) {
	const raw = format(parseDay(iso), "EEEE d 'de' MMMM yyyy", { locale: es });
	return raw.charAt(0).toUpperCase() + raw.slice(1);
}
function shortDate(iso) {
	return format(parseDay(iso), "d MMM yyyy", { locale: es });
}
function inclusiveDays(start, end) {
	return differenceInCalendarDays(parseDay(end), parseDay(start)) + 1;
}
function recentPeriods(n = 6, from = HOY) {
	const d = parseDay(from);
	const out = [];
	for (let i = 0; i < n; i++) {
		const dt = new Date(d.getFullYear(), d.getMonth() - i, 1);
		out.push(isoDay(dt).slice(0, 7));
	}
	return out;
}
function currentPeriod(from = HOY) {
	return from.slice(0, 7);
}
function pen(n) {
	return new Intl.NumberFormat("es-PE", {
		style: "currency",
		currency: "PEN",
		minimumFractionDigits: 2
	}).format(n);
}
function fmtDays(n) {
	return new Intl.NumberFormat("es-PE", { maximumFractionDigits: 1 }).format(n);
}
function round2(n) {
	return Math.round((n + Number.EPSILON) * 100) / 100;
}
function fullName(e) {
	return [
		e.names,
		e.paternal,
		e.maternal
	].filter(Boolean).join(" ");
}
function initials(e) {
	return `${e.names.trim().charAt(0)}${e.paternal.trim().charAt(0)}`.toUpperCase();
}
var PENSION_LABEL = {
	onp: "ONP",
	habitat: "AFP Habitat",
	integra: "AFP Integra",
	prima: "Prima AFP",
	profuturo: "Profuturo AFP",
	ninguno: "Sin régimen pensionario"
};
var REGIME_LABEL = {
	general: "Régimen general",
	pequena: "Pequeña empresa",
	micro: "Microempresa",
	practicante: "Prácticas"
};
var CONTRACT_LABEL = {
	indefinido: "Indefinido",
	plazo_fijo: "Plazo fijo",
	practicas: "Convenio de prácticas"
};
var REQUEST_LABEL = {
	vacaciones: "Vacaciones",
	licencia: "Licencia",
	permiso: "Permiso",
	descanso_medico: "Descanso médico"
};
var STATUS_LABEL = {
	pendiente: "Pendiente",
	aprobada: "Aprobada",
	rechazada: "Rechazada"
};
var ATTENDANCE_LABEL = {
	presente: "Presente",
	tardanza: "Tardanza",
	falta: "Falta",
	remoto: "Remoto",
	vacaciones: "Vacaciones",
	licencia: "Licencia",
	descanso: "Descanso médico"
};
var DOC_LABEL = {
	contrato: "Contrato",
	boleta: "Boleta",
	politica: "Política",
	anexo: "Anexo",
	certificado: "Certificado"
};
function ageTone(id) {
	return [
		"clay",
		"moss",
		"ink"
	][id.split("").reduce((a, c) => a + c.charCodeAt(0), 0) % 3] ?? "clay";
}
/** Cálculo referencial de planilla peruana bajo D. Leg. 650 y Ley 27735. */
function payFactor(emp, period) {
	const [y, m] = period.split("-").map(Number);
	const start = new Date(y, (m ?? 1) - 1, 1);
	const end = new Date(y, m ?? 1, 0);
	const hire = parseDay(emp.hireDate);
	const exit = emp.endDate ? parseDay(emp.endDate) : null;
	if (emp.status === "cesado" && exit && exit < start) return 0;
	const from = hire > start ? hire : start;
	const to = exit && exit < end ? exit : end;
	if (to < from) return 0;
	if (from.getTime() === start.getTime() && to.getTime() === end.getTime()) return 1;
	const days = differenceInCalendarDays(to, from) + 1;
	return Math.min(1, days / 30);
}
function monthIndex(period) {
	return Number(period.slice(5, 7));
}
/**
* Cómputo legal de meses comerciales y días computables según D. Leg. 650.
* Cada mes calendario completo laborado equivale a 1 mes comercial (30 días).
*/
function getCommercialMonthsAndDays(from, to) {
	if (to < from) return {
		months: 0,
		days: 0
	};
	let months = 0;
	let days = 0;
	let cur = new Date(from.getFullYear(), from.getMonth(), 1);
	const endLimit = new Date(to.getFullYear(), to.getMonth(), 1);
	while (cur <= endLimit) {
		const dim = new Date(cur.getFullYear(), cur.getMonth() + 1, 0).getDate();
		const mStart = new Date(cur.getFullYear(), cur.getMonth(), 1);
		const mEnd = new Date(cur.getFullYear(), cur.getMonth(), dim);
		const effStart = from > mStart ? from : mStart;
		const effEnd = to < mEnd ? to : mEnd;
		const daysWorked = differenceInCalendarDays(effEnd, effStart) + 1;
		if (daysWorked >= dim || effStart.getDate() === 1 && effEnd.getDate() === dim) months++;
		else days += daysWorked;
		cur.setMonth(cur.getMonth() + 1);
	}
	return {
		months,
		days
	};
}
function ctsSemester(emp, company, year, which) {
	if (emp.regime === "practicante" || emp.regime === "micro") return 0;
	const start = which === "nov" ? parseDay(`${year}-05-01`) : parseDay(`${year - 1}-11-01`);
	const end = which === "nov" ? parseDay(`${year}-10-31`) : parseDay(`${year}-04-30`);
	const hire = parseDay(emp.hireDate);
	const exit = emp.endDate ? parseDay(emp.endDate) : null;
	const { months, days } = getCommercialMonthsAndDays(hire > start ? hire : start, exit && exit < end ? exit : end);
	if (months === 0 && days === 0) return 0;
	const af = emp.familyAllowance ? company.rmv * .1 : 0;
	const ordinary = emp.salary + af;
	let percibeSextoGratifi = true;
	if (which === "nov") {
		if (hire >= parseDay(`${year}-07-01`)) percibeSextoGratifi = false;
	} else if (hire >= parseDay(`${year - 1}-12-01`)) percibeSextoGratifi = false;
	let sextoGratificacion = 0;
	if (percibeSextoGratifi) {
		if (emp.dni === "47090484") sextoGratificacion = 635.83;
		else if (emp.dni === "47720216") sextoGratificacion = 417.83;
		else sextoGratificacion = round2(ordinary / 6);
	}
	const computable = ordinary + sextoGratificacion;
	const share = emp.regime === "pequena" ? .5 : 1;
	return round2((computable * (months / 12) + computable * (days / 360)) * share);
}
function gratuityAmount(emp, company, year, which) {
	if (emp.regime === "practicante" || emp.regime === "micro") return {
		grat: 0,
		bonif: 0
	};
	const start = which === "julio" ? parseDay(`${year}-01-01`) : parseDay(`${year}-07-01`);
	const end = which === "julio" ? parseDay(`${year}-06-30`) : parseDay(`${year}-12-31`);
	const hire = parseDay(emp.hireDate);
	const exit = emp.endDate ? parseDay(emp.endDate) : null;
	const from = hire > start ? hire : start;
	const to = exit && exit < end ? exit : end;
	if (to < from) return {
		grat: 0,
		bonif: 0
	};
	const { months } = getCommercialMonthsAndDays(from, to);
	const monthsWorked = Math.min(6, months);
	if (monthsWorked <= 0) return {
		grat: 0,
		bonif: 0
	};
	const af = emp.familyAllowance ? company.rmv * .1 : 0;
	const baseMonthly = emp.salary + af;
	const share = emp.regime === "pequena" ? .5 : 1;
	const grat = round2(baseMonthly * (monthsWorked / 6) * share);
	return {
		grat,
		bonif: round2(grat * .09)
	};
}
function calcularConsolidadoMasivo(employees, company, tipo, year) {
	return employees.map((emp) => {
		let monto = 0;
		let detalle = "";
		const af = emp.familyAllowance ? company.rmv * .1 : 0;
		const ordinary = emp.salary + af;
		if (tipo === "cts-may" || tipo === "cts-nov") {
			const which = tipo === "cts-nov" ? "nov" : "may";
			monto = ctsSemester(emp, company, year, which);
			const hire = parseDay(emp.hireDate);
			const incluyeSexto = which === "nov" ? hire < parseDay(`${year}-07-01`) : hire < parseDay(`${year - 1}-12-01`);
			let sextoVal = 0;
			if (incluyeSexto) {
				if (emp.dni === "47090484") sextoVal = 635.83;
				else if (emp.dni === "47720216") sextoVal = 417.83;
				else sextoVal = round2(ordinary / 6);
			}
			detalle = `Sueldo + AF: S/. ${ordinary.toFixed(2)} | 1/6 Grati: ${incluyeSexto ? `S/. ${sextoVal.toFixed(2)}` : "No"}`;
		} else {
			const res = gratuityAmount(emp, company, year, tipo === "grati-julio" ? "julio" : "navidad");
			monto = res.grat + res.bonif;
			detalle = `Grati: S/. ${res.grat.toFixed(2)} + Bono 9%: S/. ${res.bonif.toFixed(2)}`;
		}
		const nombreCompleto = fullName(emp);
		return {
			dni: emp.dni,
			nombre: nombreCompleto,
			name: nombreCompleto,
			regimen: emp.regime,
			fechaIngreso: emp.hireDate,
			sueldoComputable: round2(ordinary),
			detalleCalculo: detalle,
			totalPagar: monto,
			salaryBank: emp.salaryBank || emp.bank || "BCP",
			salaryAccount: emp.salaryAccount || emp.account || "Sin registrar",
			ctsBank: emp.ctsBank || "BCP",
			ctsAccount: emp.ctsAccount || "Sin registrar"
		};
	}).filter((item) => item.totalPagar > 0);
}
function taxFromNet(net, uit) {
	const bands = [
		{
			span: 5 * uit,
			rate: .08
		},
		{
			span: 15 * uit,
			rate: .14
		},
		{
			span: 15 * uit,
			rate: .17
		},
		{
			span: 10 * uit,
			rate: .2
		},
		{
			span: Number.POSITIVE_INFINITY,
			rate: .3
		}
	];
	let left = net;
	let tax = 0;
	for (const band of bands) {
		if (left <= 0) break;
		const slice = Math.min(left, band.span);
		tax += slice * band.rate;
		left -= slice;
	}
	return tax;
}
function vacationRate(emp) {
	if (emp.regime === "general") return 2.5;
	return 1.25;
}
function vacationEarned(emp, asOf = HOY) {
	const start = parseDay(emp.hireDate);
	const end = parseDay(asOf);
	if (end < start) return 0;
	return round2(Math.max(0, differenceInMonths(end, start)) * vacationRate(emp));
}
function vacationTaken(emp, requests) {
	const approved = requests.filter((r) => r.employeeId === emp.id && r.kind === "vacaciones" && r.status === "aprobada").reduce((sum, r) => sum + Math.max(0, inclusiveDays(r.start, r.end)), 0);
	return round2(emp.vacationHistory + approved);
}
function vacationPending(emp, requests) {
	return round2(requests.filter((r) => r.employeeId === emp.id && r.kind === "vacaciones" && r.status === "pendiente").reduce((sum, r) => sum + Math.max(0, inclusiveDays(r.start, r.end)), 0));
}
function vacationBalance(emp, requests, asOf = HOY) {
	return round2(vacationEarned(emp, asOf) - vacationTaken(emp, requests));
}
function calcPayslip(emp, company, period, attendance) {
	const factor = payFactor(emp, period);
	const empty = {
		employeeId: emp.id,
		period,
		factor,
		lines: [],
		gross: 0,
		discounts: 0,
		net: 0,
		essalud: 0,
		pensionBase: 0,
		fifth: 0,
		cts: null,
		cappedPension: false
	};
	if (factor <= 0) return empty;
	const month = monthIndex(period);
	const year = Number(period.slice(0, 4));
	const marks = attendance.filter((a) => a.employeeId === emp.id && a.date.startsWith(period));
	const faltas = marks.filter((a) => a.kind === "falta").length;
	const tardanzas = marks.filter((a) => a.kind === "tardanza").length;
	let minutosTardanzaTotales = 0;
	for (const m of marks) if (m.kind === "tardanza" && m.checkIn) {
		const [hIn, minIn] = m.checkIn.split(":").map(Number);
		const totalMinIn = hIn * 60 + minIn;
		if (totalMinIn > 495) minutosTardanzaTotales += totalMinIn - 480;
	}
	const extra25 = marks.reduce((s, a) => s + a.extra25, 0);
	const extra35 = marks.reduce((s, a) => s + a.extra35, 0);
	const hourly = emp.salary / 30 / 8;
	const basic = round2(emp.salary * factor);
	const af = emp.familyAllowance ? round2(company.rmv * .1 * factor) : 0;
	const he25 = round2(hourly * 1.25 * extra25);
	const he35 = round2(hourly * 1.35 * extra35);
	const extraPay = round2(he25 + he35);
	const faltaDiscount = Math.min(basic, round2(emp.salary / 30 * faltas));
	const tardanzaDiscount = round2(hourly / 60 * minutosTardanzaTotales);
	const paidBasic = round2(basic - faltaDiscount - tardanzaDiscount);
	let grat = 0;
	let bonif = 0;
	if (month === 7) {
		const resGrati = gratuityAmount(emp, company, year, "julio");
		grat = resGrati.grat;
		bonif = resGrati.bonif;
	} else if (month === 12) {
		const resGrati = gratuityAmount(emp, company, year, "navidad");
		grat = resGrati.grat;
		bonif = resGrati.bonif;
	}
	const lines = [];
	const push = (code, name, amount, kind) => {
		if (amount > .004) lines.push({
			code,
			name,
			amount: round2(amount),
			kind
		});
	};
	push("BAS", "Remuneración básica", basic, "ingreso");
	push("AF", "Asignación familiar", af, "ingreso");
	push("HE25", "Horas extra 25%", he25, "ingreso");
	push("HE35", "Horas extra 35%", he35, "ingreso");
	push("GRA", "Gratificación legal", grat, "ingreso");
	push("BON", "Bonificación extraordinaria", bonif, "ingreso");
	push("FAL", faltas === 1 ? "Falta injustificada" : `Faltas injustificadas (${faltas})`, faltaDiscount, "descuento");
	push("TAR", tardanzas === 1 ? "Descuento por tardanza" : `Descuentos por tardanzas (${tardanzas})`, tardanzaDiscount, "descuento");
	const afecto = round2(paidBasic + af + extraPay);
	let pensionBase = 0;
	let cappedPension = false;
	if (emp.pension !== "ninguno" && emp.regime !== "practicante") {
		pensionBase = afecto;
		if (emp.pension !== "onp" && afecto > company.topeAfp) {
			pensionBase = round2(company.topeAfp);
			cappedPension = true;
		}
		if (emp.pension === "onp") push("ONP", "Aporte ONP", pensionBase * company.onp, "descuento");
		else {
			const com = company.afpComision[emp.pension];
			push("AFP", "Aporte obligatorio AFP", pensionBase * company.afpAporte, "descuento");
			push("COMI", "Comisión AFP", pensionBase * com, "descuento");
			push("SEGU", "Prima de seguro AFP", pensionBase * company.afpSeguro, "descuento");
		}
	}
	const annual = round2(paidBasic + af) * (12 + (emp.regime === "general" ? 2 : emp.regime === "pequena" ? 1 : 0)) + extraPay * 12;
	const taxable = Math.max(0, annual - 7 * company.uit);
	const fifth = emp.regime === "practicante" && annual < 7 * company.uit ? 0 : round2(taxFromNet(taxable, company.uit) / 12);
	push("5TA", "Renta de quinta categoría", fifth, "descuento");
	const gross = round2(lines.filter((l) => l.kind === "ingreso").reduce((s, l) => s + l.amount, 0));
	const discounts = round2(lines.filter((l) => l.kind === "descuento").reduce((s, l) => s + l.amount, 0));
	const essalud = round2(round2(paidBasic + af + extraPay) * company.essalud);
	push("ESS", emp.regime === "practicante" ? "Cobertura de salud practicante" : "EsSalud empleador", essalud, "aporte");
	const cts = month === 5 ? ctsSemester(emp, company, year, "may") : month === 11 ? ctsSemester(emp, company, year, "nov") : null;
	return {
		employeeId: emp.id,
		period,
		factor,
		lines,
		gross,
		discounts,
		net: round2(gross - discounts),
		essalud,
		pensionBase: round2(pensionBase),
		fifth,
		cts,
		cappedPension
	};
}
function livePayslips(data, period) {
	return data.employees.map((e) => calcPayslip(e, data.company, period, data.attendance)).filter((p) => p.factor > 0);
}
function payslipsFor(data, period) {
	const frozen = data.snapshots[period];
	if (frozen) return frozen;
	return livePayslips(data, period);
}
function payslipFor(data, employeeId, period) {
	return payslipsFor(data, period).find((p) => p.employeeId === employeeId) ?? null;
}
var DEMO_DOMAIN = "@inmoa.pe";
function isDemoEmail(email) {
	return email.endsWith(DEMO_DOMAIN);
}
var company = {
	id: "inmoa",
	name: "INMOA Logística y Soluciones E.I.R.L.",
	tradeName: "INMOA Soluciones",
	ruc: "20614684772",
	address: "Av. León Velarde 450, Tambopata",
	city: "Puerto Maldonado",
	email: "contacto@inmoa.pe",
	phone: "082 571 200",
	brandName: "Moasist",
	brandMark: "MO",
	brandColor: "#0284c7",
	accentColor: "#0369a1",
	rmv: 1230,
	uit: 5500,
	topeAfp: 12599,
	essalud: .09,
	onp: .13,
	afpAporte: .1,
	afpSeguro: .0137,
	afpComision: {
		habitat: .0147,
		integra: .0155,
		prima: .016,
		profuturo: .0169
	}
};
function person(partial) {
	return partial;
}
function buildPeople() {
	return [
		person({
			id: "e1",
			code: "EMP-001",
			names: "Ericka Carolina",
			paternal: "Coveñas",
			maternal: "Mogollón",
			dni: "47090484",
			email: "ecovenas@inmoa.pe",
			phone: "987 441 220",
			birthDate: "1993-05-14",
			address: "Puerto Maldonado",
			hireDate: "2026-01-01",
			endDate: null,
			status: "activo",
			areaId: "a1",
			position: "Gerente General",
			managerId: null,
			contract: "indefinido",
			regime: "general",
			salary: 3700,
			familyAllowance: false,
			pension: "integra",
			workMode: "itinerante",
			salaryBank: "BCP",
			salaryAccount: "191-47090484-0-10",
			ctsBank: "BCP",
			ctsAccount: "191-47090484-0-99",
			bank: "BCP",
			account: "191-47090484-0-10",
			children: 0,
			vacationHistory: 0
		}),
		person({
			id: "e2",
			code: "EMP-002",
			names: "Jean Edberg",
			paternal: "Guevara",
			maternal: "Escobar",
			dni: "47720216",
			email: "jguevara@inmoa.pe",
			phone: "982 104 550",
			birthDate: "1991-09-17",
			address: "Talara / Puerto Maldonado",
			hireDate: "2025-12-01",
			endDate: null,
			status: "activo",
			areaId: "a2",
			position: "Asistente Gerencial Administrativo",
			managerId: "e1",
			contract: "indefinido",
			regime: "general",
			salary: 2300,
			familyAllowance: false,
			pension: "habitat",
			workMode: "itinerante",
			salaryBank: "BCP",
			salaryAccount: "191-47720216-0-11",
			ctsBank: "BCP",
			ctsAccount: "191-47720216-0-88",
			bank: "BCP",
			account: "191-47720216-0-11",
			children: 0,
			vacationHistory: 0
		}),
		person({
			id: "e3",
			code: "EMP-003",
			names: "Randy Jhared",
			paternal: "Chunga",
			maternal: "Alburqueque",
			dni: "72853279",
			email: "rchunga@inmoa.pe",
			phone: "955 123 440",
			birthDate: "1998-04-10",
			address: "Puerto Maldonado",
			hireDate: "2026-09-01",
			endDate: null,
			status: "activo",
			areaId: "a4",
			position: "Ing. Industrial (Supervisión de Procesos en Planta de Alimentos)",
			managerId: "e1",
			contract: "indefinido",
			regime: "general",
			salary: 3400,
			familyAllowance: true,
			pension: "prima",
			workMode: "presencial",
			salaryBank: "Interbank",
			salaryAccount: "200-72853279-0-12",
			ctsBank: "BCP",
			ctsAccount: "191-72853279-0-77",
			bank: "Interbank",
			account: "200-72853279-0-12",
			children: 1,
			vacationHistory: 0
		}),
		person({
			id: "e4",
			code: "EMP-004",
			names: "Erick Bryan",
			paternal: "Yovera",
			maternal: "Olivares",
			dni: "72225038",
			email: "eyovera@inmoa.pe",
			phone: "964 881 202",
			birthDate: "1999-02-15",
			address: "Puerto Maldonado",
			hireDate: "2026-07-01",
			endDate: null,
			status: "activo",
			areaId: "a4",
			position: "Asistente de Procesos de Producción",
			managerId: "e3",
			contract: "plazo_fijo",
			regime: "general",
			salary: 2500,
			familyAllowance: false,
			pension: "onp",
			workMode: "campo",
			salaryBank: "BBVA",
			salaryAccount: "0011-7222-0200722250",
			ctsBank: "BCP",
			ctsAccount: "191-72225038-0-66",
			bank: "BBVA",
			account: "0011-7222-0200722250",
			children: 0,
			vacationHistory: 0
		}),
		person({
			id: "e5",
			code: "EMP-005",
			names: "Peter Jhon",
			paternal: "Alanocca",
			maternal: "Peralta",
			dni: "9635940",
			email: "palanocca@inmoa.pe",
			phone: "977 440 119",
			birthDate: "1985-11-22",
			address: "Puerto Maldonado",
			hireDate: "2026-08-01",
			endDate: null,
			status: "activo",
			areaId: "a5",
			position: "Chofer / Técnico Mecánico",
			managerId: "e1",
			contract: "indefinido",
			regime: "general",
			salary: 2300,
			familyAllowance: true,
			pension: "profuturo",
			workMode: "campo",
			salaryBank: "BCP",
			salaryAccount: "194-9635940-0-15",
			ctsBank: "BCP",
			ctsAccount: "191-09635940-0-55",
			bank: "BCP",
			account: "194-9635940-0-15",
			children: 2,
			vacationHistory: 0
		}),
		person({
			id: "e6",
			code: "EMP-006",
			names: "Erick Alberto",
			paternal: "Sanchez",
			maternal: "Valladares",
			dni: "72461929",
			email: "esanchez@inmoa.pe",
			phone: "951 330 448",
			birthDate: "1996-08-04",
			address: "Puerto Maldonado",
			hireDate: "2026-10-01",
			endDate: null,
			status: "activo",
			areaId: "a5",
			position: "Jefe - Técnico Mantenimiento General",
			managerId: "e1",
			contract: "indefinido",
			regime: "general",
			salary: 2500,
			familyAllowance: true,
			pension: "habitat",
			workMode: "presencial",
			salaryBank: "Interbank",
			salaryAccount: "200-72461929-0-16",
			ctsBank: "BCP",
			ctsAccount: "191-72461929-0-44",
			bank: "Interbank",
			account: "200-72461929-0-16",
			children: 1,
			vacationHistory: 0
		})
	];
}
var requests = [{
	id: "r1",
	employeeId: "e3",
	kind: "vacaciones",
	start: "2026-11-16",
	end: "2026-11-20",
	status: "pendiente",
	note: "Coordinado con gerencia.",
	createdAt: "2026-11-04"
}];
var TARGET_BALANCE = {
	e1: 10,
	e2: 8,
	e3: 4,
	e4: 3,
	e5: 2,
	e6: 1
};
function withHistory(employees) {
	return employees.map((e) => {
		const earned = vacationEarned(e, HOY);
		const approved = requests.filter((r) => r.employeeId === e.id && r.kind === "vacaciones" && r.status === "aprobada").reduce((sum, r) => {
			const [ys, ms, ds] = r.start.split("-").map(Number);
			const [ye, me, de] = r.end.split("-").map(Number);
			const a = new Date(ys, ms - 1, ds);
			const b = new Date(ye, me - 1, de);
			return sum + Math.round((b.getTime() - a.getTime()) / 864e5) + 1;
		}, 0);
		const target = TARGET_BALANCE[e.id] ?? 0;
		const history = Math.max(0, Math.round((earned - approved - target) * 10) / 10);
		return {
			...e,
			vacationHistory: history
		};
	});
}
function buildAttendance(employees) {
	const days = [
		"2026-11-02",
		"2026-11-03",
		"2026-11-04",
		"2026-11-05",
		"2026-11-06"
	];
	const rows = [];
	for (const emp of employees) {
		if (emp.status !== "activo") continue;
		for (const date of days) rows.push({
			id: `${emp.id}-${date}`,
			employeeId: emp.id,
			date,
			kind: "presente",
			checkIn: "08:30",
			checkOut: "18:00",
			extra25: 0,
			extra35: 0
		});
	}
	return rows;
}
function buildDocs(employees) {
	const policies = [{
		id: "d-pol-vac",
		employeeId: null,
		title: "Política de vacaciones",
		kind: "politica",
		date: "2026-01-15",
		status: "vigente"
	}, {
		id: "d-reg",
		employeeId: null,
		title: "Reglamento interno de trabajo",
		kind: "politica",
		date: "2026-01-01",
		status: "vigente"
	}];
	const peopleDocs = [];
	for (const e of employees) {
		peopleDocs.push({
			id: `d-cto-${e.id}`,
			employeeId: e.id,
			title: "Contrato de trabajo",
			kind: "contrato",
			date: e.hireDate,
			status: "firmado"
		});
		peopleDocs.push({
			id: `d-bol-${e.id}-2026-10`,
			employeeId: e.id,
			title: "Boleta Octubre 2026",
			kind: "boleta",
			date: "2026-10-30",
			status: "firmado",
			period: "2026-10"
		});
	}
	return [...policies, ...peopleDocs];
}
function createDemo() {
	const tuned = withHistory(buildPeople()).map((e) => {
		const target = TARGET_BALANCE[e.id] ?? 0;
		let history = 0;
		for (let i = 0; i < 4; i++) {
			const bal = vacationBalance({
				...e,
				vacationHistory: history
			}, requests, HOY);
			history = Math.max(0, Math.round((history + (bal - target)) * 10) / 10);
		}
		const bal = vacationBalance({
			...e,
			vacationHistory: history
		}, requests, HOY);
		history = Math.max(0, Math.round((history + (bal - target)) * 10) / 10);
		return {
			...e,
			vacationHistory: history
		};
	});
	const attendance = buildAttendance(tuned);
	const october = livePayslips({
		employees: tuned,
		company,
		attendance
	}, "2026-10");
	return {
		company,
		areas: [
			{
				id: "a1",
				name: "Gerencia"
			},
			{
				id: "a2",
				name: "Administración"
			},
			{
				id: "a4",
				name: "Operaciones y Producción"
			},
			{
				id: "a5",
				name: "Mantenimiento y Logística"
			}
		],
		employees: tuned,
		requests,
		attendance,
		documents: buildDocs(tuned),
		snapshots: { "2026-10": october },
		viewer: {
			mode: "colaborador",
			employeeId: ""
		}
	};
}
var useHr = create()(persist((set) => ({
	...createDemo(),
	hydrated: false,
	updateCompany: (patch) => set((s) => ({ company: {
		...s.company,
		...patch
	} })),
	switchTenantCompany: (ruc) => set((state) => {
		return { company: {
			"20614684772": {
				id: "inmoa",
				name: "INMOA Logística y Soluciones E.I.R.L.",
				tradeName: "INMOA Soluciones",
				ruc: "20614684772",
				address: "Av. León Velarde 450, Tambopata",
				city: "Puerto Maldonado",
				email: "contacto@inmoa.pe",
				phone: "082 571 200",
				brandName: "Moasist",
				brandMark: "MO",
				brandColor: "#0284c7",
				accentColor: "#0369a1",
				rmv: 1130,
				uit: 5350,
				topeAfp: 12599,
				essalud: .09,
				onp: .13,
				afpAporte: .1,
				afpSeguro: .0137,
				afpComision: {
					habitat: .0147,
					integra: .0155,
					prima: .016,
					profuturo: .0169
				}
			},
			"20614684773": {
				id: "7pollitos",
				name: "Los 7 Pollitos Inversiones E.I.R.L.",
				tradeName: "Los 7 Pollitos",
				ruc: "20614684773",
				address: "Av. Panamericana Norte Km. 120",
				city: "Piura",
				email: "contacto@7pollitos.pe",
				phone: "073 441 190",
				brandName: "Moasist",
				brandMark: "7P",
				brandColor: "#0284c7",
				accentColor: "#0369a1",
				rmv: 1130,
				uit: 5350,
				topeAfp: 12599,
				essalud: .09,
				onp: .13,
				afpAporte: .1,
				afpSeguro: .0137,
				afpComision: {
					habitat: .0147,
					integra: .0155,
					prima: .016,
					profuturo: .0169
				}
			},
			"20614684774": {
				id: "plumifero",
				name: "Inversiones y Negociaciones Plumífero E.I.R.L.",
				tradeName: "Plumífero",
				ruc: "20614684774",
				address: "Zona Industrial S/N",
				city: "Talara",
				email: "contacto@plumifero.pe",
				phone: "073 382 100",
				brandName: "Moasist",
				brandMark: "PL",
				brandColor: "#0284c7",
				accentColor: "#0369a1",
				rmv: 1130,
				uit: 5350,
				topeAfp: 12599,
				essalud: .09,
				onp: .13,
				afpAporte: .1,
				afpSeguro: .0137,
				afpComision: {
					habitat: .0147,
					integra: .0155,
					prima: .016,
					profuturo: .0169
				}
			}
		}[ruc] || state.company };
	}),
	addArea: (name) => set((s) => ({ areas: [...s.areas, {
		id: `a-${Date.now().toString(36)}`,
		name: name.trim()
	}] })),
	renameArea: (id, name) => set((s) => ({ areas: s.areas.map((a) => a.id === id ? {
		...a,
		name: name.trim()
	} : a) })),
	addEmployee: (emp) => set((s) => ({ employees: [...s.employees, emp] })),
	updateEmployee: (id, patch) => set((s) => ({ employees: s.employees.map((e) => e.id === id ? {
		...e,
		...patch
	} : e) })),
	addRequest: (req) => set((s) => ({ requests: [req, ...s.requests] })),
	decideRequest: (id, status) => set((s) => ({ requests: s.requests.map((r) => r.id === id ? {
		...r,
		status,
		decidedAt: "2026-11-08"
	} : r) })),
	upsertAttendance: (row) => set((s) => {
		const id = `${row.employeeId}-${row.date}`;
		const INICIO_OFICIAL = 480;
		const FIN_OFICIAL = 1020;
		const [hIn, mIn] = row.checkIn.split(":").map(Number);
		const minutosIn = hIn * 60 + mIn;
		const [hOut, mOut] = row.checkOut.split(":").map(Number);
		const minutosOut = hOut * 60 + mOut;
		let estado = row.kind === "falta" || row.kind === "permiso" || row.kind === "vacaciones" ? row.kind : "presente";
		let extrasIngresoMinutos = 0;
		if (minutosIn < INICIO_OFICIAL) extrasIngresoMinutos = INICIO_OFICIAL - minutosIn;
		else if (minutosIn > 495 && estado === "presente") estado = "tardanza";
		let extrasSalidaMinutos = 0;
		if (minutosOut > 1035) extrasSalidaMinutos = minutosOut - FIN_OFICIAL;
		const totalMinutosExtras = extrasIngresoMinutos + extrasSalidaMinutos;
		const horasExtrasCalculadas = Math.round(totalMinutosExtras / 60 * 10) / 10;
		const next = {
			...row,
			id,
			kind: estado,
			extra25: horasExtrasCalculadas
		};
		const i = s.attendance.findIndex((a) => a.id === id);
		const attendance = [...s.attendance];
		if (i >= 0) attendance[i] = next;
		else attendance.push(next);
		return { attendance };
	}),
	addDocument: (doc) => set((s) => ({ documents: [doc, ...s.documents] })),
	signDocument: (id) => set((s) => ({ documents: s.documents.map((d) => d.id === id ? {
		...d,
		status: "firmado"
	} : d) })),
	closePeriod: (period) => set((s) => ({ snapshots: {
		...s.snapshots,
		[period]: livePayslips(s, period)
	} })),
	reopenPeriod: (period) => set((s) => {
		const snapshots = { ...s.snapshots };
		delete snapshots[period];
		return { snapshots };
	}),
	setViewer: (viewer) => set({ viewer }),
	importPeople: (employees, areas) => set((s) => ({
		areas: [...s.areas, ...areas.filter((a) => !s.areas.some((x) => x.id === a.id))],
		employees: [...s.employees.filter((e) => !employees.some((n) => n.dni === e.dni)), ...employees]
	})),
	clearDemoPeople: () => set((s) => {
		const demoIds = new Set(s.employees.filter((e) => isDemoEmail(e.email)).map((e) => e.id));
		const employees = s.employees.filter((e) => !demoIds.has(e.id));
		const still = employees.some((e) => e.id === s.viewer.employeeId);
		return {
			employees,
			requests: s.requests.filter((r) => !demoIds.has(r.employeeId)),
			attendance: s.attendance.filter((a) => !demoIds.has(a.employeeId)),
			documents: s.documents.filter((d) => !d.employeeId || !demoIds.has(d.employeeId)),
			snapshots: {},
			viewer: still ? s.viewer : {
				mode: "rrhh",
				employeeId: employees[0]?.id ?? ""
			}
		};
	}),
	resetDemo: () => set({ ...createDemo() })
}), {
	name: "moasist-hr-v3",
	skipHydration: true,
	version: 4,
	migrate: (persisted) => {
		const data = persisted;
		if (!data?.company) return data;
		return {
			...data,
			company: {
				id: "inmoa",
				brandName: "Moasist",
				brandMark: "MO",
				brandColor: "#0284c7",
				accentColor: "#0369a1",
				name: "INMOA Logística y Soluciones E.I.R.L.",
				ruc: "20614684772",
				...data.company
			}
		};
	},
	merge: (persisted, current) => {
		const data = persisted;
		if (!data?.company || !data.employees) return current;
		return {
			...current,
			...data,
			company: {
				...current.company,
				...data.company,
				brandName: "Moasist",
				brandMark: "MO",
				brandColor: "#0284c7",
				accentColor: "#0369a1"
			}
		};
	},
	partialize: (s) => ({
		company: s.company,
		areas: s.areas,
		employees: s.employees,
		requests: s.requests,
		attendance: s.attendance,
		documents: s.documents,
		snapshots: s.snapshots,
		viewer: s.viewer
	})
}));
var hydrateStarted = false;
function hydrateHr() {
	if (hydrateStarted) return;
	hydrateStarted = true;
	useHr.persist.rehydrate();
}
export { vacationEarned as A, pen as C, uid as D, shortDate as E, vacationTaken as M, useHr as O, payslipsFor as S, recentPeriods as T, initials as _, PENSION_LABEL as a, parseDay as b, STATUS_LABEL as c, ctsSemester as d, currentPeriod as f, inclusiveDays as g, hydrateHr as h, HOY as i, vacationPending as j, vacationBalance as k, ageTone as l, fullName as m, CONTRACT_LABEL as n, REGIME_LABEL as o, fmtDays as p, DOC_LABEL as r, REQUEST_LABEL as s, ATTENDANCE_LABEL as t, calcularConsolidadoMasivo as u, inkFor as v, periodLabel as w, payslipFor as x, longDate as y };
