import { i as __toESM } from "../_runtime.mjs";
import { o as PageHeader, s as Shell } from "./shell-DnMRrmUQ.mjs";
import { O as useHr, _ as initials, l as ageTone, m as fullName } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/organizacion-_c1u1B-Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TONES = {
	clay: "bg-clay text-clay-ink",
	moss: "bg-moss text-moss-ink",
	ink: "bg-ink text-clay-ink"
};
function OrgPage() {
	const employees = useHr((s) => s.employees);
	const areas = useHr((s) => s.areas);
	const [tab, setTab] = (0, import_react.useState)("arbol");
	const active = employees.filter((e) => e.status === "activo");
	const roots = active.filter((e) => !e.managerId || !active.some((x) => x.id === e.managerId));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Estructura",
			title: "Organización",
			lede: "Jerarquía por jefatura y distribución por área. Los sueldos no se muestran en esta vista."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab("arbol"),
				className: `min-h-11 rounded-md px-3 text-sm ${tab === "arbol" ? "bg-ink text-clay-ink" : "bg-surface text-muted"}`,
				children: "Jerarquía"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab("areas"),
				className: `min-h-11 rounded-md px-3 text-sm ${tab === "areas" ? "bg-ink text-clay-ink" : "bg-surface text-muted"}`,
				children: "Áreas"
			})]
		}),
		tab === "arbol" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: roots.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tree, {
				node: r,
				all: active
			}, r.id))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: areas.map((a) => {
				const members = active.filter((e) => e.areaId === a.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl",
							children: a.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [members.length, " personas"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-2",
							children: members.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonChip, { emp: m }) }, m.id))
						})
					]
				}, a.id);
			})
		})
	] });
}
function Tree({ node, all }) {
	const kids = all.filter((e) => e.managerId === node.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonChip, { emp: node }), kids.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid gap-3 border-l border-line pl-4 sm:grid-cols-2",
			children: kids.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tree, {
				node: k,
				all
			}, k.id))
		}) : null]
	});
}
function PersonChip({ emp }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/colaboradores/$id",
		params: { id: emp.id },
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `grid size-10 shrink-0 place-items-center rounded-md text-sm ${TONES[ageTone(emp.id)]}`,
			children: initials(emp)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm font-medium",
			children: fullName(emp)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs text-muted",
			children: emp.position
		})] })]
	});
}
export { OrgPage as component };
