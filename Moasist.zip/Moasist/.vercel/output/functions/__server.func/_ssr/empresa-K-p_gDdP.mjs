import { i as __toESM } from "../_runtime.mjs";
import { a as Modal, c as fieldClass, i as Field, n as Button, o as PageHeader, s as Shell } from "./shell-DnMRrmUQ.mjs";
import { O as useHr } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
// node_modules/.nitro/vite/services/ssr/assets/empresa-K-p_gDdP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FUNDS = [
	{
		id: "habitat",
		label: "AFP Habitat"
	},
	{
		id: "integra",
		label: "AFP Integra"
	},
	{
		id: "prima",
		label: "Prima AFP"
	},
	{
		id: "profuturo",
		label: "Profuturo"
	}
];
var PALETTES = [
	{
		name: "Arcilla",
		brand: "#c4512c",
		accent: "#1f4d40"
	},
	{
		name: "Océano",
		brand: "#0f4c81",
		accent: "#c4512c"
	},
	{
		name: "Bosque",
		brand: "#1f4d40",
		accent: "#a16207"
	},
	{
		name: "Noche",
		brand: "#1e1a16",
		accent: "#c4512c"
	},
	{
		name: "Cobalto",
		brand: "#243e73",
		accent: "#0f766e"
	}
];
function hexOr(value) {
	return /^#[0-9a-fA-F]{6}$/.test(value) ? value : "#c4512c";
}
function CompanyPage() {
	const company = useHr((s) => s.company);
	const areas = useHr((s) => s.areas);
	const employees = useHr((s) => s.employees);
	const updateCompany = useHr((s) => s.updateCompany);
	const addArea = useHr((s) => s.addArea);
	const renameArea = useHr((s) => s.renameArea);
	const clearDemoPeople = useHr((s) => s.clearDemoPeople);
	const resetDemo = useHr((s) => s.resetDemo);
	const [areaName, setAreaName] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	const setNum = (key, raw) => {
		const n = Number(raw);
		if (Number.isFinite(n)) updateCompany({ [key]: n });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Tu empresa",
			title: "Configuración",
			lede: "Cambia la razón social, el RUC y los parámetros de planilla. Los valores iniciales siguen la referencia 2026: RMV S/ 1,130, UIT S/ 5,350 y comisiones AFP por flujo."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-lg border border-line bg-surface p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: "Identidad"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Razón social",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: company.name,
							onChange: (e) => updateCompany({ name: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nombre comercial",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: company.tradeName,
							onChange: (e) => updateCompany({ tradeName: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "RUC",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: company.ruc,
							onChange: (e) => updateCompany({ ruc: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ciudad",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: company.city,
							onChange: (e) => updateCompany({ city: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Dirección",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: company.address,
							onChange: (e) => updateCompany({ address: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Correo de personas",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: company.email,
							onChange: (e) => updateCompany({ email: e.target.value })
						})
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 rounded-lg border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Marca y colores"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "El nombre y los colores se ven en el menú, los botones y las boletas. El cambio queda guardado en este navegador."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: PALETTES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "min-h-11 rounded-md border border-line bg-bg px-3 text-sm",
						onClick: () => updateCompany({
							brandColor: p.brand,
							accentColor: p.accent
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 inline-block size-3 rounded-sm",
							style: { background: p.brand }
						}), p.name]
					}, p.name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nombre del producto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: company.brandName,
								maxLength: 24,
								onChange: (e) => updateCompany({ brandName: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Inicial del isotipo",
							hint: "Una o dos letras.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: company.brandMark,
								maxLength: 2,
								onChange: (e) => updateCompany({ brandMark: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Color principal",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-11 w-full cursor-pointer rounded-md border border-line bg-surface",
								type: "color",
								value: hexOr(company.brandColor),
								onChange: (e) => updateCompany({ brandColor: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Color de acento",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-11 w-full cursor-pointer rounded-md border border-line bg-surface",
								type: "color",
								value: hexOr(company.accentColor),
								onChange: (e) => updateCompany({ accentColor: e.target.value })
							})
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 rounded-lg border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Parámetros de planilla"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Ajusta estas tasas cuando cambie la norma. El cálculo es referencial y no presenta el PLAME."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "RMV (S/)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: String(company.rmv),
								onChange: (e) => setNum("rmv", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "UIT (S/)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: String(company.uit),
								onChange: (e) => setNum("uit", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tope AFP (S/)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: String(company.topeAfp),
								onChange: (e) => setNum("topeAfp", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pct, {
							label: "EsSalud %",
							value: company.essalud,
							onChange: (n) => updateCompany({ essalud: n })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pct, {
							label: "ONP %",
							value: company.onp,
							onChange: (n) => updateCompany({ onp: n })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pct, {
							label: "Aporte AFP %",
							value: company.afpAporte,
							onChange: (n) => updateCompany({ afpAporte: n })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pct, {
							label: "Prima de seguro %",
							value: company.afpSeguro,
							onChange: (n) => updateCompany({ afpSeguro: n })
						}),
						FUNDS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pct, {
							label: `Comisión flujo ${f.label} %`,
							value: company.afpComision[f.id],
							onChange: (n) => updateCompany({ afpComision: {
								...company.afpComision,
								[f.id]: n
							} })
						}, f.id))
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 rounded-lg border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Áreas"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: areas.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: a.name,
							onChange: (e) => renameArea(a.id, e.target.value),
							"aria-label": `Área ${a.name}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-xs text-muted",
							children: employees.filter((e) => e.areaId === a.id && e.status === "activo").length
						})]
					}, a.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						placeholder: "Nueva área",
						value: areaName,
						onChange: (e) => setAreaName(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "line",
						onClick: () => {
							if (!areaName.trim()) return;
							addArea(areaName);
							setAreaName("");
							toast.success("Área creada");
						},
						children: "Agregar"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 rounded-lg border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Datos de ejemplo"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Andes & Cacao es una empresa ficticia para recorrer el producto. Puedes quitar a esas personas y conservar el nombre de tu empresa, o volver a cargar la demostración completa."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "line",
						onClick: () => setConfirm("clear"),
						children: "Quitar personas de ejemplo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "danger",
						onClick: () => setConfirm("reset"),
						children: "Restablecer demostración"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open: confirm !== null,
			title: confirm === "reset" ? "Restablecer demostración" : "Quitar personas de ejemplo",
			onClose: () => setConfirm(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: confirm === "reset" ? "Se vuelve a cargar Andes & Cacao, con sus colaboradores, marcas y la planilla de octubre cerrada. Lo que hayas cambiado se pierde en este navegador." : "Se eliminan los colaboradores @andescacao.pe, sus solicitudes y boletas. La razón social y los parámetros se quedan."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					tone: "ghost",
					onClick: () => setConfirm(null),
					children: "Cancelar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						if (confirm === "reset") resetDemo();
						else clearDemoPeople();
						setConfirm(null);
						toast.success(confirm === "reset" ? "Demostración restaurada" : "Personas de ejemplo retiradas");
					},
					children: "Confirmar"
				})]
			})]
		})
	] });
}
function Pct({ label, value, onChange }) {
	const shown = String(Math.round(value * 1e4) / 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: fieldClass,
			value: shown,
			onChange: (e) => {
				const n = Number(e.target.value);
				if (Number.isFinite(n)) onChange(n / 100);
			}
		})
	});
}
export { CompanyPage as component };
