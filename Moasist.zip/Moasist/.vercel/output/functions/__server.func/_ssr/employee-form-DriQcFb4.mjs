import { c as fieldClass, i as Field } from "./shell-DnMRrmUQ.mjs";
import { a as PENSION_LABEL, n as CONTRACT_LABEL, o as REGIME_LABEL } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/employee-form-DriQcFb4.js
var import_jsx_runtime = require_jsx_runtime();
function draftFromEmployee(e) {
	const { id: _id, code: _code, ...rest } = e;
	return rest;
}
function validateDraft(d) {
	if (!d.names.trim() || !d.paternal.trim()) return "Indica nombres y apellido paterno.";
	if (!/^\d{8}$/.test(d.dni)) return "El DNI debe tener 8 dígitos.";
	if (!d.position.trim()) return "Indica el cargo.";
	if (!d.areaId) return "Elige un área.";
	if (!Number.isFinite(d.salary) || d.salary < 0) return "El sueldo no es válido.";
	if (!/^\d{4}-\d{2}-\d{2}$/.test(d.hireDate)) return "La fecha de ingreso no es válida.";
	return null;
}
function EmployeeForm({ value, areas, managers, onChange }) {
	const set = (key, v) => onChange({
		...value,
		[key]: v
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nombres",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: value.names,
					onChange: (e) => set("names", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Apellido paterno",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: value.paternal,
					onChange: (e) => set("paternal", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Apellido materno",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: value.maternal,
					onChange: (e) => set("maternal", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "DNI",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					inputMode: "numeric",
					value: value.dni,
					onChange: (e) => set("dni", e.target.value.replace(/\D/g, "").slice(0, 8))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Correo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					type: "email",
					value: value.email,
					onChange: (e) => set("email", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Celular",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: value.phone,
					onChange: (e) => set("phone", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Fecha de nacimiento",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					type: "date",
					value: value.birthDate,
					onChange: (e) => set("birthDate", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Fecha de ingreso",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					type: "date",
					value: value.hireDate,
					onChange: (e) => set("hireDate", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Cargo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: value.position,
					onChange: (e) => set("position", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Área",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: fieldClass,
					value: value.areaId,
					onChange: (e) => set("areaId", e.target.value),
					children: areas.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: a.id,
						children: a.name
					}, a.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Jefatura",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: fieldClass,
					value: value.managerId ?? "",
					onChange: (e) => set("managerId", e.target.value || null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Sin jefatura"
					}), managers.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: m.id,
						children: [
							m.names,
							" ",
							m.paternal
						]
					}, m.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Sueldo mensual (S/)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					inputMode: "decimal",
					value: String(value.salary),
					onChange: (e) => set("salary", Number(e.target.value))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Contrato",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: fieldClass,
					value: value.contract,
					onChange: (e) => set("contract", e.target.value),
					children: Object.keys(CONTRACT_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: k,
						children: CONTRACT_LABEL[k]
					}, k))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Régimen laboral",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: fieldClass,
					value: value.regime,
					onChange: (e) => {
						const regime = e.target.value;
						onChange({
							...value,
							regime,
							pension: regime === "practicante" ? "ninguno" : value.pension,
							contract: regime === "practicante" ? "practicas" : value.contract
						});
					},
					children: Object.keys(REGIME_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: k,
						children: REGIME_LABEL[k]
					}, k))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Pensión",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: fieldClass,
					value: value.pension,
					onChange: (e) => set("pension", e.target.value),
					children: Object.keys(PENSION_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: k,
						children: PENSION_LABEL[k]
					}, k))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Hijos",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					inputMode: "numeric",
					value: String(value.children),
					onChange: (e) => {
						const children = Math.max(0, Number(e.target.value) || 0);
						onChange({
							...value,
							children,
							familyAllowance: children > 0
						});
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Banco",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: value.bank,
					onChange: (e) => set("bank", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Cuenta",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: value.account,
					onChange: (e) => set("account", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-2 text-sm sm:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: value.familyAllowance,
					onChange: (e) => set("familyAllowance", e.target.checked)
				}), "Asignación familiar (10% de la RMV)"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Vacaciones ya gozadas antes de Minka",
				hint: "Sirve al migrar el saldo histórico.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					inputMode: "decimal",
					value: String(value.vacationHistory),
					onChange: (e) => set("vacationHistory", Number(e.target.value) || 0)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Fin de contrato",
				hint: "Vacío si no tiene fecha de cese.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					type: "date",
					value: value.endDate ?? "",
					onChange: (e) => set("endDate", e.target.value || null)
				})
			})
		]
	});
}
export { draftFromEmployee as n, validateDraft as r, EmployeeForm as t };
