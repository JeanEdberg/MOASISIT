import { i as __toESM } from "../_runtime.mjs";
import { a as Modal, c as fieldClass, i as Field, n as Button, o as PageHeader, s as Shell, t as Badge } from "./shell-DnMRrmUQ.mjs";
import { r as visibleEmployees, t as canApprove } from "./access-CMOdfdyo.mjs";
import { A as vacationEarned, D as uid, E as shortDate, M as vacationTaken, O as useHr, b as parseDay, c as STATUS_LABEL, g as inclusiveDays, i as HOY, j as vacationPending, k as vacationBalance, m as fullName, p as fmtDays, s as REQUEST_LABEL } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
// node_modules/.nitro/vite/services/ssr/assets/vacaciones-DBeZtKaD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VacationsPage() {
	const data = useHr();
	const addRequest = useHr((s) => s.addRequest);
	const decideRequest = useHr((s) => s.decideRequest);
	const people = visibleEmployees(data.employees, data.viewer).filter((e) => e.status === "activo");
	const [tab, setTab] = (0, import_react.useState)("saldos");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [month, setMonth] = (0, import_react.useState)("2026-11");
	const [form, setForm] = (0, import_react.useState)({
		employeeId: data.viewer.employeeId || people[0]?.id || "",
		kind: "vacaciones",
		start: "2026-11-16",
		end: "2026-11-20",
		note: ""
	});
	const [error, setError] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => {
		return people.map((e) => ({
			e,
			earned: vacationEarned(e),
			taken: vacationTaken(e, data.requests),
			pending: vacationPending(e, data.requests),
			balance: vacationBalance(e, data.requests)
		})).sort((a, b) => b.balance - a.balance);
	}, [people, data.requests]);
	const total = rows.reduce((s, r) => s + r.balance, 0);
	const avg = rows.length ? total / rows.length : 0;
	const visibleReqs = data.requests.filter((r) => people.some((e) => e.id === r.employeeId));
	const submit = () => {
		if (!form.employeeId) {
			setError("Elige a la persona.");
			return;
		}
		if (form.end < form.start) {
			setError("La fecha de fin no puede ser anterior al inicio.");
			return;
		}
		const days = inclusiveDays(form.start, form.end);
		if (days <= 0 || days > 60) {
			setError("Revisa el rango de fechas.");
			return;
		}
		if (data.requests.some((r) => r.employeeId === form.employeeId && r.status !== "rechazada" && r.start <= form.end && form.start <= r.end)) {
			setError("Ya hay una solicitud que se cruza con esas fechas.");
			return;
		}
		const emp = data.employees.find((e) => e.id === form.employeeId);
		if (form.kind === "vacaciones" && emp) {
			const bal = vacationBalance(emp, data.requests);
			if (days > bal + .05) {
				setError(`El saldo es ${fmtDays(bal)} días. Ajusta el rango o registra el adelanto con RR. HH.`);
				return;
			}
		}
		const req = {
			id: uid("r"),
			employeeId: form.employeeId,
			kind: form.kind,
			start: form.start,
			end: form.end,
			status: "pendiente",
			note: form.note.trim(),
			createdAt: HOY
		};
		addRequest(req);
		setOpen(false);
		setTab("solicitudes");
		toast.success("Solicitud enviada");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Tiempo libre",
			title: "Vacaciones",
			lede: "Saldo a 2.5 días por mes en régimen general, y 1.25 en pequeña empresa, microempresa y prácticas.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => {
					setError(null);
					setForm((f) => ({
						...f,
						employeeId: data.viewer.mode === "colaborador" ? data.viewer.employeeId : f.employeeId || data.viewer.employeeId || people[0]?.id || ""
					}));
					setOpen(true);
				},
				children: "Nueva solicitud"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Saldo visible",
					value: `${fmtDays(total)} días`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Promedio",
					value: `${fmtDays(avg)} días`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "En trámite",
					value: String(visibleReqs.filter((r) => r.status === "pendiente").length)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex gap-2 overflow-x-auto",
			children: [
				["saldos", "Saldos"],
				["solicitudes", "Solicitudes"],
				["calendario", "Calendario"]
			].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(key),
				className: `min-h-11 shrink-0 rounded-md px-3 text-sm ${tab === key ? "bg-ink text-clay-ink" : "bg-surface text-muted"}`,
				children: label
			}, key))
		}),
		tab === "saldos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-lg border border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-max min-w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Colaborador"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Ganados"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Gozados"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Trámite"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Saldo"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: fullName(r.e)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted",
								children: data.areas.find((a) => a.id === r.e.areaId)?.name
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "num px-4 py-3",
							children: fmtDays(r.earned)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "num px-4 py-3",
							children: fmtDays(r.taken)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "num px-4 py-3",
							children: fmtDays(r.pending)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "num px-4 py-3 font-medium",
							children: fmtDays(r.balance)
						})
					]
				}, r.e.id)) })]
			})
		}) : null,
		tab === "solicitudes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-3",
			children: visibleReqs.map((r) => {
				const who = data.employees.find((e) => e.id === r.employeeId);
				const can = canApprove(data.viewer, data.employees, r.employeeId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: who ? fullName(who) : "Colaborador"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									REQUEST_LABEL[r.kind],
									" · ",
									shortDate(r.start),
									" – ",
									shortDate(r.end),
									" · ",
									inclusiveDays(r.start, r.end),
									" días"
								]
							}),
							r.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm",
								children: r.note
							}) : null
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: r.status === "aprobada" ? "moss" : r.status === "rechazada" ? "line" : "clay",
							children: STATUS_LABEL[r.status]
						})]
					}), r.status === "pendiente" && can ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								decideRequest(r.id, "aprobada");
								toast.success("Solicitud aprobada");
							},
							children: "Aprobar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							tone: "line",
							onClick: () => {
								decideRequest(r.id, "rechazada");
								toast.success("Solicitud rechazada");
							},
							children: "Rechazar"
						})]
					}) : null]
				}, r.id);
			})
		}) : null,
		tab === "calendario" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex gap-2",
			children: ["2026-11", "2026-12"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setMonth(m),
				className: `min-h-11 rounded-md px-3 text-sm ${month === m ? "bg-ink text-clay-ink" : "bg-surface text-muted"}`,
				children: m === "2026-11" ? "Noviembre" : "Diciembre"
			}, m))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthGrid, {
			month,
			items: visibleReqs.filter((r) => r.status !== "rechazada" && r.start.slice(0, 7) <= month && r.end.slice(0, 7) >= month),
			nameOf: (id) => {
				const e = data.employees.find((x) => x.id === id);
				return e ? e.names : "";
			}
		})] }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			title: "Nueva solicitud",
			onClose: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					data.viewer.mode !== "colaborador" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Colaborador",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: form.employeeId,
							onChange: (e) => setForm({
								...form,
								employeeId: e.target.value
							}),
							children: people.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: e.id,
								children: fullName(e)
							}, e.id))
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tipo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: form.kind,
							onChange: (e) => setForm({
								...form,
								kind: e.target.value
							}),
							children: Object.keys(REQUEST_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: k,
								children: REQUEST_LABEL[k]
							}, k))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Desde",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "date",
								value: form.start,
								onChange: (e) => setForm({
									...form,
									start: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Hasta",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "date",
								value: form.end,
								onChange: (e) => setForm({
									...form,
									end: e.target.value
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nota",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: fieldClass,
							rows: 3,
							value: form.note,
							onChange: (e) => setForm({
								...form,
								note: e.target.value
							})
						})
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-clay",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: submit,
						children: "Enviar a aprobación"
					})
				]
			})
		})
	] });
}
function Mini({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "num mt-1 font-display text-2xl",
			children: value
		})]
	});
}
function MonthGrid({ month, items, nameOf }) {
	const [y, m] = month.split("-").map(Number);
	const pad = (parseDay(`${month}-01`).getDay() + 6) % 7;
	const count = new Date(y, m, 0).getDate();
	const cells = [...Array(pad).fill(null), ...Array.from({ length: count }, (_, i) => i + 1)];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-7 gap-1 text-center text-xs text-muted",
		children: [
			"L",
			"M",
			"X",
			"J",
			"V",
			"S",
			"D"
		].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "py-1",
			children: d
		}, d))
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-7 gap-1",
		children: cells.map((day, i) => {
			if (!day) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `e-${i}`);
			const iso = `${month}-${String(day).padStart(2, "0")}`;
			const hits = items.filter((r) => r.start <= iso && iso <= r.end);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-16 rounded-md border border-line bg-surface p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "num text-xs",
					children: day
				}), hits.slice(0, 2).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `truncate text-xs ${h.status === "aprobada" ? "text-moss" : "text-clay"}`,
					children: nameOf(h.employeeId)
				}, h.id))]
			}, iso);
		})
	})] });
}
export { VacationsPage as component };
