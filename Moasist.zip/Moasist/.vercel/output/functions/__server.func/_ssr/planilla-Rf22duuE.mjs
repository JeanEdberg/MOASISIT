import { i as __toESM } from "../_runtime.mjs";
import { t as BoletaView } from "./boleta-BAZMyUwB.mjs";
import { a as Modal, n as Button, o as PageHeader, r as Empty, s as Shell } from "./shell-DnMRrmUQ.mjs";
import { n as canSeeMoney, r as visibleEmployees } from "./access-CMOdfdyo.mjs";
import { C as pen, D as uid, O as useHr, S as payslipsFor, T as recentPeriods, f as currentPeriod, i as HOY, m as fullName, w as periodLabel } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
// node_modules/.nitro/vite/services/ssr/assets/planilla-Rf22duuE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PayrollPage() {
	const data = useHr();
	const closePeriod = useHr((s) => s.closePeriod);
	const reopenPeriod = useHr((s) => s.reopenPeriod);
	const addDocument = useHr((s) => s.addDocument);
	const [period, setPeriod] = (0, import_react.useState)(currentPeriod());
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const people = visibleEmployees(data.employees, data.viewer);
	const slips = (0, import_react.useMemo)(() => {
		return payslipsFor(data, period).filter((p) => people.some((e) => e.id === p.employeeId) && canSeeMoney(data.viewer, p.employeeId));
	}, [
		data,
		period,
		people
	]);
	const closed = Boolean(data.snapshots[period]);
	const neto = slips.reduce((s, p) => s + p.net, 0);
	const bruto = slips.reduce((s, p) => s + p.gross, 0);
	const desc = slips.reduce((s, p) => s + p.discounts, 0);
	const ess = slips.reduce((s, p) => s + p.essalud, 0);
	const cts = slips.reduce((s, p) => s + (p.cts ?? 0), 0);
	const showCts = period.endsWith("-05") || period.endsWith("-11");
	const selected = slips.find((p) => p.employeeId === openId);
	const selectedEmp = data.employees.find((e) => e.id === openId);
	const exportCsv = () => {
		const csv = [[
			"codigo",
			"nombre",
			"dni",
			"ingresos",
			"descuentos",
			"neto",
			"essalud",
			"cts"
		], ...slips.map((p) => {
			const e = data.employees.find((x) => x.id === p.employeeId);
			return [
				e?.code ?? "",
				e ? fullName(e) : "",
				e?.dni ?? "",
				p.gross,
				p.discounts,
				p.net,
				p.essalud,
				p.cts ?? ""
			];
		})].map((row) => row.map((c) => `"${String(c).replaceAll("\"", "\"\"")}"`).join(",")).join("\n");
		const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `planilla-${period}.csv`;
		a.click();
		URL.revokeObjectURL(url);
	};
	const publishSlips = () => {
		let n = 0;
		for (const p of slips) {
			if (data.documents.some((d) => d.kind === "boleta" && d.employeeId === p.employeeId && d.period === period)) continue;
			addDocument({
				id: uid("d"),
				employeeId: p.employeeId,
				title: `Boleta ${periodLabel(period)}`,
				kind: "boleta",
				date: HOY,
				status: "pendiente",
				period
			});
			n += 1;
		}
		toast.success(n ? `${n} boletas quedaron en Documentos` : "Esas boletas ya estaban publicadas");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Remuneraciones",
			title: data.viewer.mode === "colaborador" ? "Mi boleta" : "Planilla",
			lede: "Sueldo, asignación familiar, AFP u ONP, quinta categoría y EsSalud. En julio y diciembre se suma la gratificación; en mayo y noviembre, la CTS del semestre.",
			actions: data.viewer.mode === "rrhh" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					tone: "line",
					onClick: exportCsv,
					children: "Exportar CSV"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					tone: "line",
					onClick: publishSlips,
					children: "Publicar boletas"
				}),
				closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					tone: "danger",
					onClick: () => reopenPeriod(period),
					children: "Reabrir mes"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						closePeriod(period);
						toast.success("Planilla cerrada");
					},
					children: "Cerrar mes"
				})
			] }) : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex gap-2 overflow-x-auto",
			children: recentPeriods(6).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setPeriod(p),
				className: `min-h-11 shrink-0 rounded-md px-3 text-sm ${period === p ? "bg-ink text-clay-ink" : "bg-surface text-muted"}`,
				children: [periodLabel(p), data.snapshots[p] ? " · cerrado" : ""]
			}, p))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Ingresos",
					value: pen(bruto)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Descuentos",
					value: pen(desc)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Neto",
					value: pen(neto)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: showCts ? "CTS del semestre" : "EsSalud empleador",
					value: pen(showCts ? cts : ess)
				})
			]
		}),
		slips.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "Sin boletas en este periodo",
			lede: "Nadie de tu vista tiene devengue en el mes elegido."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-lg border border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-max min-w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Colaborador"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Ingresos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Descuentos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Neto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3 font-medium" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: slips.map((p) => {
					const e = data.employees.find((x) => x.id === p.employeeId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: e ? fullName(e) : "—"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted",
									children: e?.position
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "num px-4 py-3",
								children: pen(p.gross)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "num px-4 py-3",
								children: pen(p.discounts)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "num px-4 py-3 font-medium",
								children: pen(p.net)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 text-sm text-clay",
									onClick: () => setOpenId(p.employeeId),
									children: "Ver boleta"
								})
							})
						]
					}, p.employeeId);
				}) })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open: Boolean(selected && selectedEmp),
			title: "Boleta de pago",
			onClose: () => setOpenId(null),
			wide: true,
			children: selected && selectedEmp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoletaView, {
				slip: selected,
				employee: selectedEmp,
				company: data.company
			}) : null
		})
	] });
}
function Mini({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "num mt-1 font-display text-2xl",
			children: value
		})]
	});
}
export { PayrollPage as component };
