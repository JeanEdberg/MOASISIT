import "../_runtime.mjs";
import { o as PageHeader, s as Shell } from "./shell-DnMRrmUQ.mjs";
import { O as useHr, m as fullName } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function generarConsolidadoMensual(employees, attendance, periodo) {
	const marcasDelMes = attendance.filter((a) => a.date.startsWith(periodo));
	return employees.map((emp) => {
		const marcasEmp = marcasDelMes.filter((m) => m.employeeId === emp.id);
		const diasPresente = marcasEmp.filter((m) => m.kind === "presente" || m.kind === "remoto").length;
		const tardanzas = marcasEmp.filter((m) => m.kind === "tardanza").length;
		const faltas = marcasEmp.filter((m) => m.kind === "falta").length;
		const extra25 = marcasEmp.reduce((sum, m) => sum + (m.extra25 || 0), 0);
		const extra35 = marcasEmp.reduce((sum, m) => sum + (m.extra35 || 0), 0);
		return {
			employeeId: emp.id,
			documento: emp.dni,
			empleado: fullName(emp),
			cargo: emp.position,
			diasPresente,
			tardanzas,
			faltas,
			horasExtra25: extra25,
			horasExtra35: extra35,
			totalHorasExtra: extra25 + extra35
		};
	});
}
function ConsolidadoAsistenciaView() {
	const { employees, attendance, company } = useHr();
	const periodoActual = "2026-11";
	const reporte = generarConsolidadoMensual(employees, attendance, periodoActual);
	const exportarACSV = () => {
		const headers = [
			"DNI",
			"Colaborador",
			"Cargo",
			"Días Presente",
			"Tardanzas",
			"Faltas",
			"Horas Extra 25%",
			"Horas Extra 35%",
			"Total H.E."
		];
		const rows = reporte.map((r) => [
			r.documento,
			`"${r.empleado}"`,
			`"${r.cargo}"`,
			r.diasPresente,
			r.tardanzas,
			r.faltas,
			r.horasExtra25,
			r.horasExtra35,
			r.totalHorasExtra
		]);
		const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
		const encodedUri = encodeURI(csvContent);
		const link = document.createElement("a");
		link.setAttribute("href", encodedUri);
		link.setAttribute("download", `Consolidado_Asistencia_${periodoActual}_${company.id}.csv`);
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 bg-white rounded-xl shadow-sm border border-slate-200 space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex justify-between items-center border-b pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-bold text-slate-900",
				children: "Consolidado Mensual de Asistencia y Tardanzas"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-slate-500",
				children: [
					"Periodo evaluado: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: periodoActual
					}),
					" (",
					company.name,
					")"
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: exportarACSV,
				className: "px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white font-semibold rounded-lg shadow-sm text-sm transition-all flex items-center gap-2 cursor-pointer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📊" }), " Exportar a Excel (CSV)"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "bg-slate-50 text-slate-700 border-b",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3",
							children: "DNI"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3",
							children: "Colaborador"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3",
							children: "Cargo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3 text-center",
							children: "Asistencias"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3 text-center",
							children: "Tardanzas"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3 text-center",
							children: "Faltas"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3 text-center",
							children: "H. Extra (25%/35%)"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: reporte.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b hover:bg-slate-50/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 font-mono text-xs",
							children: row.documento
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 font-medium text-slate-900",
							children: row.empleado
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 text-slate-600 text-xs",
							children: row.cargo
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 text-center font-semibold text-emerald-600",
							children: row.diasPresente
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 text-center font-semibold text-amber-600",
							children: row.tardanzas
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 text-center font-semibold text-rose-600",
							children: row.faltas
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "p-3 text-center text-slate-700",
							children: [row.totalHorasExtra, " hrs"]
						})
					]
				}, row.employeeId)) })]
			})
		})]
	});
}
function ConsolidadoAsistenciaPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Reportes Gerenciales",
		title: "Consolidado de Asistencia y Tardanzas",
		lede: "Resumen mensual de asistencia, tardanzas y horas extra de todo el personal para el cálculo de haberes."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsolidadoAsistenciaView, {})
	})] });
}
export { ConsolidadoAsistenciaPage as component };
