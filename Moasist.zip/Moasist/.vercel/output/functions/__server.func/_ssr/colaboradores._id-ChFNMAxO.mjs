import { i as __toESM } from "../_runtime.mjs";
import { t as BoletaView } from "./boleta-BAZMyUwB.mjs";
import { n as draftFromEmployee, r as validateDraft, t as EmployeeForm } from "./employee-form-DriQcFb4.mjs";
import { a as Modal, n as Button, s as Shell, t as Badge } from "./shell-DnMRrmUQ.mjs";
import { n as canSeeMoney, r as visibleEmployees } from "./access-CMOdfdyo.mjs";
import { A as vacationEarned, C as pen, E as shortDate, M as vacationTaken, O as useHr, T as recentPeriods, _ as initials, a as PENSION_LABEL, c as STATUS_LABEL, f as currentPeriod, i as HOY, j as vacationPending, k as vacationBalance, l as ageTone, m as fullName, n as CONTRACT_LABEL, o as REGIME_LABEL, p as fmtDays, s as REQUEST_LABEL, t as ATTENDANCE_LABEL, w as periodLabel, x as payslipFor } from "./store-BbW2cja4.mjs";
import { n as Route } from "./router-DYeyr33U.mjs";
import { C as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
// node_modules/.nitro/vite/services/ssr/assets/colaboradores._id-ChFNMAxO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TONES = {
	clay: "bg-clay text-clay-ink",
	moss: "bg-moss text-moss-ink",
	ink: "bg-ink text-clay-ink"
};
function FichaPage() {
	const { id } = Route.useParams();
	const data = useHr();
	const updateEmployee = useHr((s) => s.updateEmployee);
	const emp = data.employees.find((e) => e.id === id);
	const allowed = emp && visibleEmployees(data.employees, data.viewer).some((e) => e.id === emp.id);
	const [tab, setTab] = (0, import_react.useState)("resumen");
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const money = emp ? canSeeMoney(data.viewer, emp.id) : false;
	const area = data.areas.find((a) => a.id === emp?.areaId);
	const boss = data.employees.find((e) => e.id === emp?.managerId);
	if (!emp || !allowed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl",
			children: "Ficha no disponible"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Esta persona no está en tu vista."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/colaboradores",
			className: "mt-4 inline-flex min-h-11 items-center text-sm text-clay",
			children: "Volver al directorio"
		})
	] });
	const balance = vacationBalance(emp, data.requests);
	const marks = data.attendance.filter((a) => a.employeeId === emp.id).sort((a, b) => b.date.localeCompare(a.date));
	const reqs = data.requests.filter((r) => r.employeeId === emp.id);
	const save = () => {
		if (!draft) return;
		const err = validateDraft(draft);
		if (err) {
			setError(err);
			return;
		}
		updateEmployee(emp.id, draft);
		setEditing(false);
		toast.success("Ficha actualizada");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/colaboradores",
			className: "text-sm text-muted",
			children: "Directorio"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-col gap-4 sm:flex-row sm:items-start",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `grid size-16 shrink-0 place-items-center rounded-lg font-display text-2xl ${TONES[ageTone(emp.id)]}`,
					children: initials(emp)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-4xl",
								children: fullName(emp)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: emp.status === "activo" ? "moss" : "line",
								children: emp.status === "activo" ? "Activo" : "Cesado"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								emp.position,
								" · ",
								area?.name,
								" · ",
								emp.code
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: ["Ingreso ", shortDate(emp.hireDate)]
						})
					]
				}),
				data.viewer.mode === "rrhh" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "line",
						onClick: () => {
							setDraft(draftFromEmployee(emp));
							setError(null);
							setEditing(true);
						},
						children: "Editar ficha"
					}), emp.status === "activo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "danger",
						onClick: () => {
							updateEmployee(emp.id, {
								status: "cesado",
								endDate: HOY
							});
							toast.success("Marcado como cesado");
						},
						children: "Registrar cese"
					}) : null]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 flex gap-2 overflow-x-auto",
			children: [
				["resumen", "Resumen"],
				["personal", "Personal"],
				["laboral", "Laboral"],
				["pagos", "Pagos"],
				["tiempo", "Tiempo"]
			].filter(([key]) => key !== "pagos" || money).map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(key),
				className: `min-h-11 shrink-0 rounded-md px-3 text-sm ${tab === key ? "bg-ink text-clay-ink" : "bg-surface text-muted"}`,
				children: label
			}, key))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [
				tab === "resumen" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Jefatura",
							value: boss ? `${boss.names} ${boss.paternal}` : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Contrato",
							value: CONTRACT_LABEL[emp.contract]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Vacaciones",
							value: `${fmtDays(balance)} días`
						}),
						money ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Sueldo",
							value: pen(emp.salary)
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Régimen",
							value: REGIME_LABEL[emp.regime]
						})
					]
				}) : null,
				tab === "personal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "DNI",
							value: emp.dni
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Nacimiento",
							value: shortDate(emp.birthDate)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Correo",
							value: emp.email || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Celular",
							value: emp.phone || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Dirección",
							value: emp.address || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Hijos",
							value: String(emp.children)
						})
					]
				}) : null,
				tab === "laboral" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Área",
							value: area?.name ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Cargo",
							value: emp.position
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Régimen",
							value: REGIME_LABEL[emp.regime]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Pensión",
							value: PENSION_LABEL[emp.pension]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Banco",
							value: emp.bank || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Cuenta",
							value: emp.account || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Fin de contrato",
							value: emp.endDate ? shortDate(emp.endDate) : "Sin fecha"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Asignación familiar",
							value: emp.familyAllowance ? "Sí" : "No"
						})
					]
				}) : null,
				tab === "pagos" && money ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4",
					children: recentPeriods(4).map((period) => {
						const slip = payslipFor(data, emp.id, period);
						if (!slip) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-2 text-sm text-muted",
							children: [periodLabel(period), data.snapshots[period] ? " · cerrado" : ""]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoletaView, {
							slip,
							employee: emp,
							company: data.company
						})] }, period);
					})
				}) : null,
				tab === "tiempo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-lg border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl",
								children: "Vacaciones"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 grid grid-cols-2 gap-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
										label: "Ganados",
										value: fmtDays(vacationEarned(emp))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
										label: "Gozados y reservados",
										value: fmtDays(vacationTaken(emp, data.requests))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
										label: "En trámite",
										value: fmtDays(vacationPending(emp, data.requests))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
										label: "Saldo",
										value: fmtDays(balance)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-4 space-y-2 text-sm",
								children: [reqs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "text-muted",
									children: "Sin solicitudes."
								}) : null, reqs.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										REQUEST_LABEL[r.kind],
										" · ",
										shortDate(r.start)
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: STATUS_LABEL[r.status]
									})]
								}, r.id))]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-lg border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl",
								children: "Marcaciones"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-3 space-y-2 text-sm",
								children: [marks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "text-muted",
									children: "Sin marcas todavía."
								}) : null, marks.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										shortDate(m.date),
										" · ",
										ATTENDANCE_LABEL[m.kind]
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "num text-muted",
										children: [
											m.checkIn || "—",
											" ",
											m.checkOut ? `– ${m.checkOut}` : ""
										]
									})]
								}, m.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs text-muted",
								children: [
									"Periodo de referencia ",
									periodLabel(currentPeriod()),
									"."
								]
							})
						]
					})]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open: editing,
			title: "Editar ficha",
			onClose: () => setEditing(false),
			wide: true,
			children: [
				draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmployeeForm, {
					value: draft,
					areas: data.areas,
					managers: data.employees.filter((e) => e.id !== emp.id && e.status === "activo"),
					onChange: setDraft
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-clay",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "ghost",
						onClick: () => setEditing(false),
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: save,
						children: "Guardar cambios"
					})]
				})
			]
		})
	] });
}
function Info({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-surface px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm font-medium",
			children: value
		})]
	});
}
export { FichaPage as component };
