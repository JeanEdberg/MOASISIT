import { i as __toESM } from "../_runtime.mjs";
import { r as validateDraft, t as EmployeeForm } from "./employee-form-DriQcFb4.mjs";
import { a as Modal, c as fieldClass, n as Button, o as PageHeader, r as Empty, s as Shell, t as Badge } from "./shell-DnMRrmUQ.mjs";
import { n as canSeeMoney, r as visibleEmployees } from "./access-CMOdfdyo.mjs";
import { C as pen, D as uid, O as useHr, i as HOY, m as fullName, o as REGIME_LABEL } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
// node_modules/.nitro/vite/services/ssr/assets/colaboradores-BbsPgqXC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PENSIONS = /* @__PURE__ */ new Set([
	"onp",
	"habitat",
	"integra",
	"prima",
	"profuturo",
	"ninguno"
]);
var CSV_SAMPLE = `nombres,paterno,materno,dni,email,cargo,area,sueldo,ingreso,pension,hijos
Ana,Pérez,López,45678912,ana.perez@miempresa.pe,Analista,Finanzas,3500,2024-01-15,onp,1
Luis,García,Quispe,40112233,luis.garcia@miempresa.pe,Asistente,Operaciones,1800,2025-03-01,habitat,0`;
function unquote(value) {
	const v = value.trim();
	if (v.startsWith("\"") && v.endsWith("\"")) return v.slice(1, -1).replaceAll("\"\"", "\"");
	return v;
}
function splitCsvLine(line) {
	const out = [];
	let cur = "";
	let quoted = false;
	for (let i = 0; i < line.length; i++) {
		const ch = line[i];
		if (quoted) {
			if (ch === "\"" && line[i + 1] === "\"") {
				cur += "\"";
				i++;
			} else if (ch === "\"") quoted = false;
			else cur += ch;
		} else if (ch === "\"") quoted = true;
		else if (ch === ",") {
			out.push(cur);
			cur = "";
		} else cur += ch;
	}
	out.push(cur);
	return out.map(unquote);
}
function parseEmployeeCsv(text, existingAreas, startCode) {
	const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
	const errors = [];
	if (lines.length < 2) return {
		employees: [],
		areas: [],
		errors: ["El archivo no tiene filas de datos."]
	};
	const header = splitCsvLine(lines[0] ?? "").map((h) => h.toLowerCase());
	const idx = (name) => header.indexOf(name);
	for (const key of [
		"nombres",
		"paterno",
		"dni",
		"cargo",
		"area",
		"sueldo",
		"ingreso"
	]) if (idx(key) < 0) errors.push(`Falta la columna ${key}.`);
	if (errors.length) return {
		employees: [],
		areas: [],
		errors
	};
	const areas = [...existingAreas];
	const employees = [];
	let code = startCode;
	for (let r = 1; r < lines.length; r++) {
		const cols = splitCsvLine(lines[r] ?? "");
		const get = (name) => cols[idx(name)]?.trim() ?? "";
		const names = get("nombres");
		const paternal = get("paterno");
		const dni = get("dni").replace(/\D/g, "");
		const position = get("cargo");
		const areaName = get("area");
		const salary = Number(get("sueldo").replace(",", "."));
		const hireDate = get("ingreso");
		if (!names || !paternal || !position || !areaName) {
			errors.push(`Fila ${r + 1}: faltan nombres, apellido, cargo o área.`);
			continue;
		}
		if (!/^\d{8}$/.test(dni)) {
			errors.push(`Fila ${r + 1}: el DNI debe tener 8 dígitos.`);
			continue;
		}
		if (!Number.isFinite(salary) || salary < 0) {
			errors.push(`Fila ${r + 1}: sueldo inválido.`);
			continue;
		}
		if (!/^\d{4}-\d{2}-\d{2}$/.test(hireDate)) {
			errors.push(`Fila ${r + 1}: ingreso debe ser AAAA-MM-DD.`);
			continue;
		}
		let area = areas.find((a) => a.name.toLowerCase() === areaName.toLowerCase());
		if (!area) {
			area = {
				id: `a-${dni}`,
				name: areaName
			};
			areas.push(area);
		}
		const pensionRaw = (get("pension") || "onp").toLowerCase();
		const pension = PENSIONS.has(pensionRaw) ? pensionRaw : "onp";
		const children = Math.max(0, Number(get("hijos") || "0") || 0);
		const maternal = get("materno");
		const email = get("email") || `${names}.${paternal}`.toLowerCase().replace(/\s+/g, "") + "@empresa.pe";
		code += 1;
		employees.push({
			id: `imp-${dni}`,
			code: `EMP-${String(code).padStart(3, "0")}`,
			names,
			paternal,
			maternal,
			dni,
			email,
			phone: "",
			birthDate: "1995-01-01",
			address: "",
			hireDate,
			endDate: null,
			status: "activo",
			areaId: area.id,
			position,
			managerId: null,
			contract: "indefinido",
			regime: "general",
			salary,
			familyAllowance: children > 0,
			pension,
			bank: "BCP",
			account: "",
			children
		});
	}
	if (!employees.length && !errors.length) errors.push("No se importó ninguna fila.");
	return {
		employees: employees.map((e) => ({
			...e,
			hireDate: e.hireDate || "2026-11-08"
		})),
		areas: areas.filter((a) => !existingAreas.some((x) => x.id === a.id)),
		errors
	};
}
function emptyDraft(areaId) {
	return {
		names: "",
		paternal: "",
		maternal: "",
		dni: "",
		email: "",
		phone: "",
		birthDate: "1995-01-01",
		address: "",
		hireDate: HOY,
		endDate: null,
		status: "activo",
		areaId,
		position: "",
		managerId: null,
		contract: "indefinido",
		regime: "general",
		salary: 1130,
		familyAllowance: false,
		pension: "onp",
		bank: "BCP",
		account: "",
		children: 0,
		vacationHistory: 0
	};
}
function PeoplePage() {
	const employees = useHr((s) => s.employees);
	const areas = useHr((s) => s.areas);
	const viewer = useHr((s) => s.viewer);
	const addEmployee = useHr((s) => s.addEmployee);
	const importPeople = useHr((s) => s.importPeople);
	const [q, setQ] = (0, import_react.useState)("");
	const [area, setArea] = (0, import_react.useState)("todas");
	const [status, setStatus] = (0, import_react.useState)("activo");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(() => emptyDraft(areas[0]?.id ?? ""));
	const [error, setError] = (0, import_react.useState)(null);
	const [csvMsg, setCsvMsg] = (0, import_react.useState)(null);
	const visible = visibleEmployees(employees, viewer);
	const rows = (0, import_react.useMemo)(() => {
		return visible.filter((e) => {
			if (status !== "todos" && e.status !== status) return false;
			if (area !== "todas" && e.areaId !== area) return false;
			return `${fullName(e)} ${e.dni} ${e.position} ${e.code}`.toLowerCase().includes(q.trim().toLowerCase());
		});
	}, [
		visible,
		status,
		area,
		q
	]);
	const save = () => {
		const err = validateDraft(draft);
		if (err) {
			setError(err);
			return;
		}
		const emp = {
			...draft,
			id: uid("e"),
			code: `EMP-${String(employees.length + 1).padStart(3, "0")}`
		};
		addEmployee(emp);
		setOpen(false);
		toast.success("Colaborador agregado");
	};
	const onCsv = async (file) => {
		const parsed = parseEmployeeCsv(await file.text(), areas, employees.length);
		if (parsed.errors.length && parsed.employees.length === 0) {
			setCsvMsg(parsed.errors.join(" "));
			return;
		}
		importPeople(parsed.employees.map((e) => ({
			...e,
			vacationHistory: 0
		})), parsed.areas);
		setCsvMsg(`Se importaron ${parsed.employees.length} personas${parsed.errors.length ? `. Avisos: ${parsed.errors.join(" ")}` : "."}`);
		toast.success("Importación lista");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Directorio",
			title: viewer.mode === "jefatura" ? "Tu equipo" : "Colaboradores",
			lede: "Ficha laboral, régimen, pensión y sueldo. La vista de jefatura no muestra remuneraciones.",
			actions: viewer.mode === "rrhh" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					tone: "line",
					onClick: () => downloadText("plantilla-colaboradores.csv", CSV_SAMPLE),
					children: "Plantilla CSV"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex min-h-11 cursor-pointer items-center rounded-md border border-line bg-surface px-4 text-sm",
					children: ["Importar CSV", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: ".csv,text/csv",
						className: "sr-only",
						onChange: (e) => {
							const file = e.target.files?.[0];
							if (file) onCsv(file);
							e.target.value = "";
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						setDraft(emptyDraft(areas[0]?.id ?? ""));
						setError(null);
						setOpen(true);
					},
					children: "Nueva persona"
				})
			] }) : null
		}),
		csvMsg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: csvMsg
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-2 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					placeholder: "Buscar nombre, DNI o cargo",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: fieldClass,
					value: area,
					onChange: (e) => setArea(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "todas",
						children: "Todas las áreas"
					}), areas.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: a.id,
						children: a.name
					}, a.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: fieldClass,
					value: status,
					onChange: (e) => setStatus(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "activo",
							children: "Activos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "cesado",
							children: "Cesados"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "todos",
							children: "Todos"
						})
					]
				})
			]
		}),
		rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "Sin resultados",
			lede: "Prueba otro filtro o agrega colaboradores de tu empresa."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-lg border border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-max min-w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Colaborador"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Cargo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Área"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Régimen"
						}),
						viewer.mode === "rrhh" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Sueldo"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Estado"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/colaboradores/$id",
								params: { id: e.id },
								className: "font-medium",
								children: fullName(e)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted",
								children: [
									e.code,
									" · DNI ",
									e.dni
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: e.position
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: areas.find((a) => a.id === e.areaId)?.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: REGIME_LABEL[e.regime]
						}),
						viewer.mode === "rrhh" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "num px-4 py-3",
							children: canSeeMoney(viewer, e.id) ? pen(e.salary) : "—"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: e.status === "activo" ? "moss" : "line",
								children: e.status === "activo" ? "Activo" : "Cesado"
							})
						})
					]
				}, e.id)) })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open,
			title: "Nueva persona",
			onClose: () => setOpen(false),
			wide: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmployeeForm, {
					value: draft,
					areas,
					managers: employees.filter((e) => e.status === "activo"),
					onChange: setDraft
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-clay",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "ghost",
						onClick: () => setOpen(false),
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: save,
						children: "Guardar"
					})]
				})
			]
		})
	] });
}
function downloadText(name, text) {
	const blob = new Blob([text], { type: "text/csv;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	a.click();
	URL.revokeObjectURL(url);
}
export { PeoplePage as component };
