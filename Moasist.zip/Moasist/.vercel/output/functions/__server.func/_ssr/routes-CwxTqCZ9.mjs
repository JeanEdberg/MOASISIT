import { i as __toESM } from "../_runtime.mjs";
import { s as Shell, t as Badge } from "./shell-DnMRrmUQ.mjs";
import { n as canSeeMoney, r as visibleEmployees } from "./access-CMOdfdyo.mjs";
import { C as pen, E as shortDate, O as useHr, S as payslipsFor, b as parseDay, d as ctsSemester, f as currentPeriod, i as HOY, j as vacationPending, k as vacationBalance, m as fullName, p as fmtDays, s as REQUEST_LABEL, w as periodLabel } from "./store-BbW2cja4.mjs";
import { n as useOfflineSync } from "./useOfflineSync-C_zBBdYp.mjs";
import { C as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as differenceInCalendarDays } from "../_libs/date-fns.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/routes-CwxTqCZ9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const data = useHr();
	const period = currentPeriod();
	const people = visibleEmployees(data.employees, data.viewer);
	const me = data.employees.find((e) => e.id === data.viewer.employeeId);
	const active = people.filter((e) => e.status === "activo");
	const { sincronizando, pendientesCount, sincronizarPendientes } = useOfflineSync();
	const slips = (0, import_react.useMemo)(() => payslipsFor(data, period).filter((p) => people.some((e) => e.id === p.employeeId)), [
		data,
		period,
		people
	]);
	const neto = slips.reduce((s, p) => s + p.net, 0);
	const bruto = slips.reduce((s, p) => s + p.gross, 0);
	const cts = active.reduce((s, e) => s + (ctsSemester(e, data.company, 2026, "nov") ?? 0), 0);
	const pending = data.requests.filter((r) => r.status === "pendiente" && people.some((e) => e.id === r.employeeId));
	const birthdays = active.filter((e) => e.birthDate.slice(5, 7) === "11");
	const ending = active.filter((e) => e.endDate).map((e) => ({
		e,
		days: differenceInCalendarDays(parseDay(e.endDate), parseDay(HOY))
	})).filter((x) => x.days >= 0 && x.days <= 120).sort((a, b) => a.days - b.days);
	const hoyStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
	const asistenciasHoy = data.attendance.filter((a) => a.date === hoyStr && people.some((e) => e.id === a.employeeId));
	const faltasSemana = data.attendance.filter((a) => a.kind === "falta" && people.some((e) => e.id === a.employeeId)).length;
	const tardanzasSemana = data.attendance.filter((a) => a.kind === "tardanza" && people.some((e) => e.id === a.employeeId)).length;
	const chart = data.areas.map((a) => ({
		name: a.name,
		n: data.employees.filter((e) => e.areaId === a.id && e.status === "activo").length
	})).filter((x) => x.n > 0);
	const [wide, setWide] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(min-width: 1024px)");
		const apply = () => setWide(mq.matches);
		apply();
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, []);
	const hello = me ? `Hola, ${me.names.split(" ")[0]}` : "Hola";
	const showMoney = data.viewer.mode === "rrhh" || data.viewer.mode === "colaborador";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		pendientesCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-center justify-between text-xs text-amber-800",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "relative flex h-2.5 w-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Tienes ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: pendientesCount }),
					" marcación(es) almacenada(s) fuera de línea en el celular."
				] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: sincronizarPendientes,
				disabled: sincronizando || !navigator.onLine,
				className: "px-2.5 py-1 bg-amber-600 text-white rounded font-semibold hover:bg-amber-700 disabled:opacity-50 cursor-pointer",
				children: sincronizando ? "Sincronizando..." : "Sincronizar ahora"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-clay",
				children: [periodLabel(period), " · Moasist Geofencing Engine v2.6"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 mt-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-4xl font-bold",
					children: hello
				}), me && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					tone: "ink",
					children: ["MODALIDAD: ", me.workMode.toUpperCase()]
				})]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/asistencia",
					className: "inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg shadow-sm text-sm transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📥" }), " Fichar Asistencia"]
				}), data.viewer.mode === "rrhh" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/consolidado-asistencia",
					className: "inline-flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-lg shadow-sm text-sm transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📊" }), " Consolidado Mensual"]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm text-muted",
			children: data.viewer.mode === "rrhh" ? `${data.company.tradeName} tiene la planilla de noviembre abierta, el control de tardanzas sincronizado y el depósito de CTS del semestre en puerta.` : data.viewer.mode === "jefatura" ? "Revisa a tu equipo, las marcaciones de campo/itinerantes de la semana y lo que está esperando tu aprobación." : "Desde aquí ves tu estado de marcación de hoy, tu saldo de vacaciones y tus boletas de pago."
		}),
		active.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-lg border border-dashed border-line bg-surface px-5 py-10 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl",
					children: "Todavía no hay colaboradores"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Carga a tu equipo desde Personas, con el formulario o un CSV."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/colaboradores",
					className: "mt-4 inline-flex min-h-11 items-center rounded-md bg-clay px-4 text-sm text-clay-ink",
					children: "Ir a personas"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Personas activas",
						value: String(active.length),
						hint: data.viewer.mode === "rrhh" ? "en toda la empresa" : "en tu vista"
					}),
					showMoney ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Neto a pagar",
						value: pen(neto),
						hint: periodLabel(period)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Marcaciones de hoy",
						value: `${asistenciasHoy.length} / ${active.length}`,
						hint: `${tardanzasSemana} tardanzas esta semana`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Solicitudes por revisar",
						value: String(pending.length),
						hint: "vacaciones, permisos y descansos"
					}),
					data.viewer.mode === "colaborador" && me ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Saldo de vacaciones",
						value: `${fmtDays(vacationBalance(me, data.requests))} d`,
						hint: `${fmtDays(vacationPending(me, data.requests))} en trámite`
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "CTS noviembre",
						value: pen(cts),
						hint: "semestre mayo – octubre"
					})
				]
			}),
			data.viewer.mode === "rrhh" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 rounded-lg border border-line border-l-4 border-l-clay bg-surface px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: "Depósito de CTS hasta el 15 de noviembre"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted",
					children: [
						"La provisión referencial del semestre es ",
						pen(cts),
						". El bruto de boletas del mes va en ",
						pen(bruto),
						" (descuentos por ",
						faltasSemana,
						" falta(s) integrados automáticamente)."
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border border-line bg-surface p-4 lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl",
							children: "Por aprobar"
						}),
						pending.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "No hay solicitudes abiertas en esta vista."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 divide-y divide-line",
							children: pending.map((r) => {
								const who = data.employees.find((e) => e.id === r.employeeId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex flex-wrap items-center justify-between gap-2 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium",
										children: who ? fullName(who) : "Colaborador"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											REQUEST_LABEL[r.kind],
											" · ",
											shortDate(r.start),
											" – ",
											shortDate(r.end)
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: "clay",
										children: "Pendiente"
									})]
								}, r.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/vacaciones",
							className: "mt-2 inline-flex min-h-11 items-center text-sm text-clay",
							children: "Abrir vacaciones"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border border-line bg-surface p-4 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl",
						children: data.viewer.mode === "rrhh" ? "Headcount por área" : "Agenda"
					}), data.viewer.mode === "rrhh" && wide ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-52",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: chart,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "name",
										tick: {
											fill: "var(--color-muted)",
											fontSize: 11
										},
										axisLine: false,
										tickLine: false,
										interval: 0
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										allowDecimals: false,
										width: 24,
										tick: {
											fill: "var(--color-muted)",
											fontSize: 11
										},
										axisLine: false,
										tickLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "n",
										fill: "var(--color-clay)",
										radius: [
											6,
											6,
											0,
											0
										]
									})
								]
							})
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-sm",
						children: chart.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "num",
								children: c.n
							})]
						}, c.name))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl",
						children: "Cumpleaños de noviembre"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-sm",
						children: birthdays.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fullName(e) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: shortDate(e.birthDate).replace(/ \d{4}$/, "")
							})]
						}, e.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl",
						children: "Contratos por vencer"
					}), ending.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Nadie de esta vista vence en los próximos 120 días."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-sm",
						children: ending.map(({ e, days }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [fullName(e), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-muted",
								children: e.position
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "num text-muted",
								children: [days, " días"]
							})]
						}, e.id))
					})]
				})]
			}),
			showMoney && me && canSeeMoney(data.viewer, me.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted",
				children: [
					"Tu boleta de ",
					periodLabel(period).toLowerCase(),
					" está en",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/planilla",
						className: "text-clay",
						children: "Planilla"
					}),
					"."
				]
			}) : null
		] })
	] });
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "num mt-2 font-display text-2xl leading-none",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted",
				children: hint
			})
		]
	});
}
export { Dashboard as component };
