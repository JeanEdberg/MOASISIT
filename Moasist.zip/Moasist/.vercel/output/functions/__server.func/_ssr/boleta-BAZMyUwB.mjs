import { C as pen, a as PENSION_LABEL, m as fullName, w as periodLabel } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/boleta-BAZMyUwB.js
var import_jsx_runtime = require_jsx_runtime();
function BoletaView({ slip, employee, company }) {
	const ingresos = slip.lines.filter((l) => l.kind === "ingreso");
	const descuentos = slip.lines.filter((l) => l.kind === "descuento");
	const aportes = slip.lines.filter((l) => l.kind === "aporte");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-lg border border-line bg-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-start justify-between gap-3 border-b border-line pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-none",
						children: company.brandName || "Minka"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm font-medium",
						children: company.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: ["RUC ", company.ruc]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							company.address,
							", ",
							company.city
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-left sm:text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Boleta de pago"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl",
							children: periodLabel(slip.period)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: employee.code
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid gap-3 text-sm sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted",
						children: "Colaborador"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-medium",
						children: fullName(employee)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted",
						children: "DNI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "num",
						children: employee.dni
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted",
						children: "Cargo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: employee.position })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted",
						children: "Régimen pensionario"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: PENSION_LABEL[employee.pension] })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineTable, {
					title: "Ingresos",
					rows: ingresos.map((l) => [l.name, pen(l.amount)])
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineTable, {
					title: "Descuentos",
					rows: descuentos.map((l) => [l.name, pen(l.amount)])
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2 border-t border-line pt-4 text-sm sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sum, {
						label: "Total ingresos",
						value: pen(slip.gross)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sum, {
						label: "Total descuentos",
						value: pen(slip.discounts)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sum, {
						label: "Neto a pagar",
						value: pen(slip.net),
						strong: true
					})
				]
			}),
			aportes.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-md bg-surface-2 px-3 py-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: "Aportes del empleador, no se descuentan del neto"
					}),
					aportes.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "num",
							children: pen(l.amount)
						})]
					}, l.code)),
					slip.cappedPension ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted",
						children: [
							"La base AFP se topó en ",
							pen(company.topeAfp),
							"."
						]
					}) : null
				]
			}) : null,
			slip.cts !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm",
				children: [
					"CTS del semestre a depositar: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "num font-medium",
						children: pen(slip.cts)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: " · no forma parte del neto de esta boleta."
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-muted",
				children: "Estimación de referencia con los parámetros de la empresa. No es una boleta electrónica ni reemplaza el PLAME."
			})
		]
	});
}
function LineTable({ title, rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "text-lg",
		children: title
	}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm text-muted",
		children: "Sin conceptos."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 divide-y divide-line border-y border-line",
		children: rows.map(([name, amount]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center justify-between gap-3 py-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "num",
				children: amount
			})]
		}, name))
	})] });
}
function Sum({ label, value, strong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "block text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: strong ? "num font-display text-2xl" : "num font-medium",
		children: value
	})] });
}
export { BoletaView as t };
