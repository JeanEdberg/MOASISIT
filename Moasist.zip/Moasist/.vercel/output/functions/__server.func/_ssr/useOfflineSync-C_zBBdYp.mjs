import { i as __toESM } from "../_runtime.mjs";
import { O as useHr } from "./store-BbW2cja4.mjs";
import { Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/useOfflineSync-C_zBBdYp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var DB_NAME = "MoasistOfflineDB";
var STORE_NAME = "pending_attendance";
var DB_VERSION = 1;
function openDB() {
	return new Promise((resolve, reject) => {
		const request = indexedDB.open(DB_NAME, DB_VERSION);
		request.onupgradeneeded = () => {
			const db = request.result;
			if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: "id" });
		};
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => reject(request.error);
	});
}
async function guardarAsistenciaOffline(registro) {
	const db = await openDB();
	return new Promise((resolve, reject) => {
		const request = db.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).put({
			...registro,
			synced: false
		});
		request.onsuccess = () => resolve();
		request.onerror = () => reject(request.error);
	});
}
async function obtenerAsistenciasPendientes() {
	const db = await openDB();
	return new Promise((resolve, reject) => {
		const request = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).getAll();
		request.onsuccess = () => resolve(request.result || []);
		request.onerror = () => reject(request.error);
	});
}
async function limpiarAsistenciasPendientes(ids) {
	const store = (await openDB()).transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME);
	for (const id of ids) store.delete(id);
}
function useOfflineSync() {
	const { attendance, upsertAttendance } = useHr();
	const [sincronizando, setSincronizando] = (0, import_react.useState)(false);
	const [pendientesCount, setPendientesCount] = (0, import_react.useState)(0);
	const sincronizarPendientes = async () => {
		if (!navigator.onLine) return;
		setSincronizando(true);
		try {
			const pendientes = await obtenerAsistenciasPendientes();
			setPendientesCount(pendientes.length);
			if (pendientes.length > 0) {
				for (const marca of pendientes) upsertAttendance(marca);
				await limpiarAsistenciasPendientes(pendientes.map((p) => p.id));
				setPendientesCount(0);
			}
		} catch (error) {
			console.error("Error al sincronizar marcaciones offline:", error);
		} finally {
			setSincronizando(false);
		}
	};
	(0, import_react.useEffect)(() => {
		obtenerAsistenciasPendientes().then((items) => setPendientesCount(items.length));
		window.addEventListener("online", sincronizarPendientes);
		return () => window.removeEventListener("online", sincronizarPendientes);
	}, [attendance]);
	return {
		sincronizando,
		pendientesCount,
		sincronizarPendientes
	};
}
export { useOfflineSync as n, guardarAsistenciaOffline as t };
