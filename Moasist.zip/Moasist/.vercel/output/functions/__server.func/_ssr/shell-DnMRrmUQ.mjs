import { i as __toESM } from "../_runtime.mjs";
import { O as useHr, h as hydrateHr, i as HOY, m as fullName, v as inkFor, y as longDate } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime, Y as require_react, m as useRouterState, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Network, d as Landmark, f as Files, g as BookOpen, h as Calculator, i as UserCheck, l as Lock, m as CalendarDays, n as Users, o as SlidersHorizontal, p as Clock, r as UserRound, s as ShieldCheck, t as X, u as LayoutDashboard } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
// node_modules/.nitro/vite/services/ssr/assets/shell-DnMRrmUQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var fieldClass = "min-h-11 w-full rounded-md border border-line bg-surface px-3 py-2 text-sm text-ink outline-none";
function Field({ label, children, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1 block text-sm text-muted",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function PageHeader({ kicker, title, lede, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-clay",
				children: kicker
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl text-ink sm:text-4xl",
				children: title
			}),
			lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-muted",
				children: lede
			}) : null
		] }), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: actions
		}) : null]
	});
}
function Button({ tone = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-medium transition-colors disabled:opacity-50", tone === "primary" && "bg-clay text-clay-ink hover:bg-ink", tone === "moss" && "bg-moss text-moss-ink hover:bg-ink", tone === "line" && "border border-line bg-surface text-ink hover:bg-surface-2", tone === "ghost" && "text-ink hover:bg-surface-2", tone === "danger" && "border border-line bg-surface text-clay hover:bg-surface-2", className),
		...props
	});
}
function Badge({ tone = "line", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-sm px-2 py-0.5 text-xs font-medium", tone === "line" && "bg-surface-2 text-muted", tone === "clay" && "bg-clay text-clay-ink", tone === "moss" && "bg-moss text-moss-ink", tone === "ink" && "bg-ink text-clay-ink"),
		children
	});
}
function Modal({ open, title, onClose, children, wide }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onClose]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center p-3 sm:items-center sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Cerrar",
			className: "absolute inset-0 bg-ink/40",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: cn("relative z-10 max-h-[88vh] w-full overflow-y-auto rounded-lg border border-line bg-surface p-5", wide ? "max-w-3xl" : "max-w-lg"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "grid size-11 place-items-center rounded-md hover:bg-surface-2",
					"aria-label": "Cerrar diálogo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), children]
		})]
	});
}
function Empty({ title, lede }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-dashed border-line bg-surface px-5 py-10 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-2 max-w-md text-sm text-muted",
			children: lede
		})]
	});
}
function DniLoginModal({ onClose }) {
	const employees = useHr((s) => s.employees);
	const setViewer = useHr((s) => s.setViewer);
	const company = useHr((s) => s.company);
	const [dniInput, setDniInput] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const handleLogin = (e) => {
		e.preventDefault();
		setError("");
		const cleanDni = dniInput.trim();
		if (cleanDni.length !== 8) {
			setError("El DNI debe tener exactamente 8 dígitos.");
			return;
		}
		const found = employees.find((emp) => emp.dni === cleanDni);
		if (!found) {
			setError("DNI no registrado en la planilla de " + company.tradeName);
			return;
		}
		const dnisRrHH = ["47090484", "47720216"];
		const dnisJefatura = ["72853279"];
		if (dnisRrHH.includes(found.dni)) setViewer({
			mode: "rrhh",
			employeeId: found.id
		});
		else if (dnisJefatura.includes(found.dni)) setViewer({
			mode: "jefatura",
			employeeId: found.id
		});
		else setViewer({
			mode: "colaborador",
			employeeId: found.id
		});
		if (onClose) onClose();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-md px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200 dark:bg-slate-900 dark:border-slate-800",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-14 place-items-center rounded-2xl bg-sky-600 text-white font-display text-2xl font-bold shadow-lg mb-4",
							children: company.brandMark || "MO"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-bold text-slate-900 dark:text-white",
							children: company.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
							children: "Sistema de Control de Asistencia y Planillas · Moasist"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleLogin,
					className: "mt-6 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2",
							children: "Ingrese su Número de DNI (8 dígitos)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							inputMode: "numeric",
							maxLength: 8,
							value: dniInput,
							onChange: (e) => setDniInput(e.target.value.replace(/\D/g, "")),
							placeholder: "Ej. 72853279",
							className: "w-full rounded-xl border-2 border-slate-300 bg-white px-4 py-3 text-center text-xl font-bold font-mono tracking-widest text-slate-900 shadow-inner focus:border-sky-600 focus:outline-none focus:ring-4 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-white",
							autoFocus: true
						})] }),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-rose-600 text-center bg-rose-50 p-2.5 rounded-lg border border-rose-200",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							className: "w-full rounded-xl bg-sky-600 py-3 text-sm font-semibold text-white shadow-md hover:bg-sky-500 transition-all flex items-center justify-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4" }), "Acceder a mi Portal"]
						}),
						onClose && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onClose,
							className: "w-full rounded-xl bg-slate-100 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-200 transition-all dark:bg-slate-800 dark:text-slate-300",
							children: "Cancelar / Cerrar"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Seguridad DNI Activa" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1 text-sky-600 font-medium",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5" }),
							" RUC ",
							company.ruc
						]
					})]
				})
			]
		})
	});
}
var RRHH = [
	{
		to: "/",
		label: "Inicio",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/colaboradores",
		label: "Personas",
		icon: Users
	},
	{
		to: "/organizacion",
		label: "Organización",
		icon: Network
	},
	{
		to: "/vacaciones",
		label: "Vacaciones",
		icon: CalendarDays
	},
	{
		to: "/asistencia",
		label: "Asistencia",
		icon: Clock
	},
	{
		to: "/planilla",
		label: "Planilla",
		icon: Landmark
	},
	{
		to: "/consolidado",
		label: "Consolidado Masivo",
		icon: Calculator
	},
	{
		to: "/documentos",
		label: "Documentos",
		icon: Files
	},
	{
		to: "/empresa",
		label: "Empresa",
		icon: SlidersHorizontal
	},
	{
		to: "/manual",
		label: "Manual",
		icon: BookOpen
	}
];
var JEFE = [
	{
		to: "/",
		label: "Inicio",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/colaboradores",
		label: "Equipo",
		icon: Users
	},
	{
		to: "/organizacion",
		label: "Organización",
		icon: Network
	},
	{
		to: "/vacaciones",
		label: "Vacaciones",
		icon: CalendarDays
	},
	{
		to: "/asistencia",
		label: "Asistencia",
		icon: Clock
	},
	{
		to: "/documentos",
		label: "Documentos",
		icon: Files
	},
	{
		to: "/manual",
		label: "Manual",
		icon: BookOpen
	}
];
var SELF = [
	{
		to: "/",
		label: "Inicio",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/vacaciones",
		label: "Vacaciones",
		icon: CalendarDays
	},
	{
		to: "/asistencia",
		label: "Asistencia",
		icon: Clock
	},
	{
		to: "/planilla",
		label: "Mi boleta",
		icon: Landmark
	},
	{
		to: "/documentos",
		label: "Documentos",
		icon: Files
	},
	{
		to: "/manual",
		label: "Manual",
		icon: BookOpen
	}
];
function itemsFor(mode) {
	if (mode === "colaborador") return SELF;
	if (mode === "jefatura") return JEFE;
	return RRHH;
}
function Shell({ children }) {
	const company = useHr((s) => s.company);
	const employees = useHr((s) => s.employees);
	const viewer = useHr((s) => s.viewer);
	const setViewer = useHr((s) => s.setViewer);
	const switchTenantCompany = useHr((s) => s.switchTenantCompany);
	const [showDniModal, setShowDniModal] = (0, import_react.useState)(!viewer.employeeId);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const me = employees.find((e) => e.id === viewer.employeeId);
	const items = itemsFor(viewer.mode);
	const activePeople = employees.filter((e) => e.status === "activo");
	const mark = (company.brandMark || company.brandName || "MO").trim().slice(0, 2).toUpperCase();
	const brand = company.brandName?.trim() || "Moasist";
	const theme = {
		"--brand": company.brandColor || "#0284c7",
		"--brand-ink": inkFor(company.brandColor || "#0284c7"),
		"--accent": company.accentColor || "#0369a1",
		"--accent-ink": inkFor(company.accentColor || "#0369a1")
	};
	(0, import_react.useEffect)(() => {
		hydrateHr();
	}, []);
	(0, import_react.useEffect)(() => {
		document.title = `${brand} · Control de Asistencia y Planillas`;
		const meta = document.querySelector("meta[name=\"theme-color\"]");
		if (meta) meta.setAttribute("content", company.brandColor || "#0284c7");
	}, [brand, company.brandColor]);
	const changeMode = (mode) => {
		const currentOk = viewer.employeeId && activePeople.some((e) => e.id === viewer.employeeId);
		setViewer({
			mode,
			employeeId: currentOk ? viewer.employeeId : activePeople[0]?.id ?? ""
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink",
		style: theme,
		children: [
			showDniModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DniLoginModal, { onClose: () => setShowDniModal(false) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface lg:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-3 px-4 py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 place-items-center rounded-xl bg-sky-600 font-display text-xl text-white shadow-md font-bold",
							children: mark
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-2xl leading-none font-bold text-slate-900 dark:text-white",
								children: brand
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-semibold tracking-wider text-sky-600 uppercase",
								children: "INMOA Soluciones"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex flex-1 flex-col gap-1 px-3",
						children: [items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
							item,
							pathname
						}, item.to)), viewer.mode === "colaborador" && viewer.employeeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/colaboradores/$id",
							params: { id: viewer.employeeId },
							className: cn("flex min-h-11 items-center gap-3 rounded-md px-3 text-sm", pathname === `/colaboradores/${viewer.employeeId}` ? "bg-surface-2 font-medium text-ink" : "text-muted hover:bg-surface-2 hover:text-ink"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4" }), "Mi ficha"]
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 py-4 text-xs text-muted",
						children: "Moasist v1.0 · Sistema Integral de Gestión"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:pl-60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "sticky top-0 z-20 border-b border-line bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-6xl flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-9 shrink-0 place-items-center rounded-md bg-sky-600 font-display text-white font-bold lg:hidden",
								children: mark
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex flex-col gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "rounded-md border border-line bg-bg px-2 py-1 text-sm font-medium text-ink focus:outline-none focus:ring-2 focus:ring-sky-500",
									value: company.ruc,
									onChange: (e) => switchTenantCompany(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "20614684772",
											children: "INMOA Logística y Soluciones E.I.R.L."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "20614684773",
											children: "Los 7 Pollitos Inversiones E.I.R.L."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "20614684774",
											children: "Inversiones y Negociaciones Plumífero E.I.R.L."
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted px-1",
									children: [
										"RUC ",
										company.ruc,
										" · ",
										longDate(HOY)
									]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 sm:ml-auto items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setShowDniModal(true),
								className: "flex items-center gap-1.5 rounded-md border border-line bg-sky-50 px-3 py-2 text-xs font-semibold text-sky-700 hover:bg-sky-100 dark:bg-sky-950/50 dark:text-sky-300 transition-colors shadow-sm",
								title: "Cambiar o validar sesión por DNI",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ingresar por DNI" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Rol"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "min-h-11 w-full rounded-md border border-line bg-bg px-2 text-sm",
									value: viewer.mode,
									onChange: (e) => changeMode(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "rrhh",
											children: "Ver como RR. HH."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "jefatura",
											children: "Ver como jefatura"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "colaborador",
											children: "Ver como colaborador"
										})
									]
								})]
							})]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto max-w-6xl px-4 py-5 pb-28 lg:px-8 lg:pb-12",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 flex gap-1 overflow-x-auto border-t border-line bg-surface px-2 py-2 lg:hidden",
				children: [items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
					item,
					pathname,
					compact: true
				}, item.to)), viewer.mode === "colaborador" && viewer.employeeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/colaboradores/$id",
					params: { id: viewer.employeeId },
					className: cn("flex min-w-16 flex-col items-center gap-1 px-2 py-1 text-xs", pathname === `/colaboradores/${viewer.employeeId}` ? "text-sky-600" : "text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-5" }), "Ficha"]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "top-center" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: me ? fullName(me) : "sin persona"
			})
		]
	});
}
function SideLink({ item, pathname, compact }) {
	const on = item.exact ? pathname === item.to : pathname === item.to || pathname.startsWith(`${item.to}/`);
	const Icon = item.icon;
	if (compact) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: item.to,
		className: cn("flex min-w-16 flex-col items-center gap-1 px-2 py-1 text-xs", on ? "text-sky-600 font-medium" : "text-muted"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: item.to,
		className: cn("flex min-h-11 items-center gap-3 rounded-md px-3 text-sm", on ? "bg-surface-2 font-medium text-ink" : "text-muted hover:bg-surface-2 hover:text-ink"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
	});
}
export { Modal as a, fieldClass as c, Field as i, Button as n, PageHeader as o, Empty as r, Shell as s, Badge as t };
