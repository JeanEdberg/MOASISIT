import { i as __toESM } from "../_runtime.mjs";
import { t as BoletaView } from "./boleta-BAZMyUwB.mjs";
import { a as Modal, n as Button, o as PageHeader, s as Shell, t as Badge } from "./shell-DnMRrmUQ.mjs";
import { n as canSeeMoney, r as visibleEmployees } from "./access-CMOdfdyo.mjs";
import { C as pen, E as shortDate, O as useHr, a as PENSION_LABEL, m as fullName, n as CONTRACT_LABEL, r as DOC_LABEL, x as payslipFor } from "./store-BbW2cja4.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
// node_modules/.nitro/vite/services/ssr/assets/documentos-iBlcBWN8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DocsPage() {
	const data = useHr();
	const signDocument = useHr((s) => s.signDocument);
	const people = visibleEmployees(data.employees, data.viewer);
	const [open, setOpen] = (0, import_react.useState)(null);
	const docs = data.documents.filter((d) => {
		if (!d.employeeId) return true;
		if (!people.some((e) => e.id === d.employeeId)) return false;
		if ((d.kind === "boleta" || d.kind === "contrato") && !canSeeMoney(data.viewer, d.employeeId)) return false;
		return true;
	});
	const emp = data.employees.find((e) => e.id === open?.employeeId);
	const slip = open?.kind === "boleta" && open.period && open.employeeId ? payslipFor(data, open.employeeId, open.period) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Legajo",
			title: "Documentos",
			lede: "Contratos, boletas y políticas en un solo lugar. Marcar como firmado es un registro interno: no es la firma electrónica del Ministerio de Trabajo."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: docs.map((d) => {
				const who = data.employees.find((e) => e.id === d.employeeId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-3 rounded-lg border border-line bg-surface px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "min-h-11 text-left",
						onClick: () => setOpen(d),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-medium",
							children: d.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted",
							children: [
								DOC_LABEL[d.kind],
								who ? ` · ${fullName(who)}` : " · Toda la empresa",
								" · ",
								shortDate(d.date)
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: d.status === "pendiente" ? "clay" : d.status === "firmado" ? "moss" : "line",
						children: d.status === "pendiente" ? "Pendiente" : d.status === "firmado" ? "Firmado" : "Vigente"
					})]
				}, d.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open: Boolean(open),
			title: open?.title ?? "Documento",
			onClose: () => setOpen(null),
			wide: true,
			children: [
				open?.kind === "boleta" && slip && emp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoletaView, {
					slip,
					employee: emp,
					company: data.company
				}) : null,
				open?.kind === "boleta" && !slip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No hay cálculo para ese periodo."
				}) : null,
				open && open.kind !== "boleta" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocBody, { doc: open }) : null,
				open?.status === "pendiente" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					onClick: () => {
						signDocument(open.id);
						setOpen({
							...open,
							status: "firmado"
						});
						toast.success("Quedó marcado como firmado");
					},
					children: "Marcar como firmado"
				}) : null
			]
		})
	] });
}
function DocBody({ doc }) {
	const data = useHr();
	const emp = data.employees.find((e) => e.id === doc.employeeId);
	const company = data.company;
	if (doc.kind === "politica") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [company.name, " ordena el tiempo de trabajo, los descansos y la documentación laboral de su personal en Minka."] }),
			doc.id.includes("vac") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El personal del régimen general gana 30 días calendario de vacaciones por año de servicios, a razón de 2.5 días por mes. Pequeña empresa, microempresa y prácticas usan 15 días al año. La solicitud la aprueba la jefatura o Personas." }) : null,
			doc.id.includes("asi") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "La jornada de referencia es de lunes a viernes. La falta injustificada descuenta un treintavo de la remuneración. Las dos primeras horas extra del día se pagan con un recargo de 25% y las siguientes con 35%." }) : null,
			doc.id.includes("reg") || doc.title.toLowerCase().includes("reglamento") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El ingreso, la subordinación y el cese se registran en la ficha. Este texto es un modelo de trabajo para la empresa y debe revisarlo su asesoría laboral antes de usarlo como reglamento oficial." }) : null
		]
	});
	if (!emp) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Sin colaborador asociado."
	});
	if (doc.kind === "certificado") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm",
		children: [
			company.name,
			", identificada con RUC ",
			company.ruc,
			", certifica que ",
			fullName(emp),
			" laboró como ",
			emp.position,
			" desde el ",
			shortDate(emp.hireDate),
			emp.endDate ? ` hasta el ${shortDate(emp.endDate)}` : "",
			"."
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				company.name,
				" (RUC ",
				company.ruc,
				"), con domicilio en ",
				company.address,
				", ",
				company.city,
				", y ",
				fullName(emp),
				", identificado con DNI ",
				emp.dni,
				", celebran un ",
				CONTRACT_LABEL[emp.contract].toLowerCase(),
				" para el cargo de ",
				emp.position,
				"."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"La remuneración mensual de referencia es ",
				pen(emp.salary),
				emp.familyAllowance ? ", más asignación familiar," : "",
				" bajo ",
				PENSION_LABEL[emp.pension],
				". Fecha de inicio: ",
				shortDate(emp.hireDate),
				"."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Modelo editable. No sustituye un contrato suscrito ni un convenio de prácticas registrado."
			})
		]
	});
}
export { DocsPage as component };
